insert into municipio (descricao) values ('teste')

select * from municipio

delete from municipio


use opinix
alter procedure proc_inserirMunicipio
@nome varchar(50)
,@uf varchar(2)
AS
BEGIN
	insert into municipio (descricao,uf) values (@nome,@uf)
END

alter procedure proc_inserirArranjo
@nome nvarchar(50)
AS
BEGIN
	SET NOCOUNT ON
	Declare @x table(id int)
	insert into arranjo (nome) 
	output inserted.id into @x
	values (@nome)

	select * from @x
END

SET NOCOUNT ON


delete from municipio

proc_inserirMunicipio 'Sao Paulo','SP'
proc_inserirArranjo 'arranjo'

select * from municipio

use opinix
select * from arranjo
select * from municipio
use opinix
delete from arranjo
delete from municipio

select * from arranjo order by id asc
select * from municipio

DBCC CHECKIDENT ('arranjo', reseed, 0);
--DBCC CHECKIDENT ('arranjo', reseed, 0);