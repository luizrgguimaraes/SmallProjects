<?php

include 'php/classes/Prod.php';
include 'php/classes/Prop.php';

include 'php/extracao.php';
include 'php/classes.php';
include 'php/utils.php';
include 'php/html.php';
include 'php/sql.php';
include 'php/cores.php';
include 'php/graficos.php';
include 'php/hiddens.php';

define('DB_HOST'        , "localhost\SQLEXPRESS");
define('DB_USER'        , null);
define('DB_PASSWORD'    , null);
define('DB_NAME'        , "opinix");
define('DB_DRIVER'      , "sqlsrv");

define('W'      , 500);
define('H'      , 500);

define('POPULACAO'      , 1);
define('URBANO'      , 2);
define('RURAL'      , 3);
define('DESLOCAMENTO'      , 4);
define('PIB'      , 5);
define('AGROPECUARIA'      , 6);
define('INDUSTRIA'      , 7);
define('SERVICOSPRIVADOS'      , 8);
define('SERVICOSPUBLICOS'      , 9);
define('IMPOSTOS'      , 10);
define('EMPRESAS'      , 11);
define('UNIDADES'      , 12);
define('LARGURABARRAMAX',25);

$stringTipos = array(
    POPULACAO => 'POPULACAO'
    ,URBANO => 'URBANO'
    ,RURAL => 'RURAL'
    ,DESLOCAMENTO => 'DESLOCAMENTO'
    ,PIB => 'PIB'
    ,AGROPECUARIA => 'AGROPECUARIA'
    ,INDUSTRIA => 'INDUSTRIA'
    ,SERVICOSPRIVADOS => 'SERVICOSPRIVADOS'
    ,SERVICOSPUBLICOS => 'SERVICOSPUBLICOS'
    ,IMPOSTOS => 'IMPOSTOS'
    ,EMPRESAS => 'EMPRESAS'
    ,UNIDADES => 'UNIDADES'
);


date_default_timezone_set('America/Sao_Paulo');
session_start();
$Conexao = Conexao::getConnection();

if(!isset($_SESSION['colorarranjo']))$_SESSION['colorarranjo']=array();
if(!isset($_SESSION['colorpropriedade']))$_SESSION['colorpropriedade']=array();

lerHiddens();

echo criarHTMLCabecario();
echo criarHTMLForm();

//limparTabelaArranjo();
//extrairDadosTab01();
//extrairDadosTab02();
//extrairDadosTab03();
consultarArranjo();

criarHTMLArranjos();
echo criarHTMLPropriedades();
echo criarHTMLCanvas();
//<button onclick =\'$("debug").innerHTML=""\'>LIMPAR DEBUG</button>

echo '<div style="display:block;">
<button onclick ="resetarPagina();">RESET</button>
<div id=debug></div></div>';

/* //TESTE PEARSON
$i = 1;
while($i<12){
    //debug($i);
    $j = $i+1;
    while($j<=12){
        //debug($i.' - '.$j);
        debug('pearson('.$stringTipos[$i].','.$stringTipos[$j].') = '.CalcularPearson(array($i, $j)));
        if(!isset($pearson[$i]))$pearson[$i] = 0;
        if(!isset($pearson[$j]))$pearson[$j] = 0;
        $pea = CalcularPearson(array($i, $j));
        $pearson[$i] += $pea;
        $pearson[$j] += $pea;
        $j++;
    }
    $i++;
}   
asort($pearson);
foreach($pearson as $key => $value){
    //debug('pearson['.$stringTipos[$key].'] = '.$value);
}   

*/

//

echo '<script>
w = '.W.';
h = '.H.';
';

    foreach($cores as $value){
        echo 'Cores.addCor("'.$value.'");';
    }

    
    
    debugSESSIONS();
    
    foreach($_SESSION['matrizCanvasArranjo'] as $canvas => $lista){
        if(!isset($_SESSION['matrizCanvasArranjoprop'][$canvas]))$_SESSION['matrizCanvasArranjoprop'][$canvas]=array();
        echo gerarGraficoPizzaPopulacao($lista,$_SESSION['matrizCanvasArranjoprop'][$canvas],$canvas);
        //echo adicionarPropriedadesGrafico(,$canvas);
        
    }
  

echo '</script>';

echo '</body></html>';fclose($filedebug);fclose($fileErro);
?>