class ColecaoCanvas{

    static add(canvasId){
        ////alert('Colecao Canvas add');
        if(ColecaoCanvas.vetor == undefined){
            ////alert('Colecao Canvas vetor indefinido');

            ColecaoCanvas.vetor = [];
        }
        if(ColecaoCanvas.count == undefined){
            ////alert('Colecao Canvas count indefinido');
            ColecaoCanvas.count = 1;
        }
        if(canvasId == undefined){
            ////alert('Colecao Canvas id externo indefinido');
            canvasId = ++ColecaoCanvas.count; 
        }else{
            if(canvasId > ColecaoCanvas.count){
                ColecaoCanvas.count = canvasId;
            }
        }
        //debug('Colecao Canvas add - canvasId='+canvasId);           
        ColecaoCanvas.vetor[canvasId] = new Canvas(canvasId);
        //debug('ColecaoCanvas.vetor[canvasId].ctx = '+ColecaoCanvas.vetor[canvasId].ctx);
        return ColecaoCanvas.vetor[canvasId].ctx; 
    }
    
}

class Canvas{
    constructor(id){
        try{
                var trTipoGrafico = document.createElement("tr");
                var tdTipoBarra = document.createElement("button");
                tdTipoBarra.setAttribute("onclick","cliqueTipoGrafico("+id+",0);");
                tdTipoBarra.innerHTML = 'Barra';
                var tdTipoPizza = document.createElement("button");
                tdTipoPizza.setAttribute("onclick","cliqueTipoGrafico("+id+",1);");
                tdTipoPizza.innerHTML = 'Pizza';
//                var tdTipoLinha = document.createElement("td");
//                tdTipoLinha.setAttribute("onclick","cliqueTipoGrafico("+id+",2);");
//                tdTipoLinha.innerHTML = 'Linha'; 


                var tr = document.createElement("tr");
        
                var td = document.createElement("td");
                var stage = document.createElement("canvas");
                stage.width = w;
                stage.height = h;
                stage.style.background = "rgba(0,0,0,0.1)";
                stage.setAttribute("onclick","cliqueCanvas("+id+");"); 
        
        
                var tdParametros = document.createElement("td");
                tdParametros.setAttribute("id","canvasParametros"+id);
                tdParametros.appendChild(tdTipoBarra);
                tdParametros.appendChild(tdTipoPizza);
 //               tdParametros.appendChild(tdTipoLinha);

              
                td.appendChild(stage) ;
                tr.appendChild(td) ;
                tr.appendChild(tdParametros);
                $("iddiv").appendChild(tr) ;
                this.ctx = stage.getContext("2d");
                //debug('ctx = '+this.ctx);    
        }catch(err){
            //alert('Erro Construtor Canvas:'+err);
        }
    }
}

function cliqueCanvas(idGrafico){
    try{
        var string = "";
        var contador = 0;
        
        var atual = Selecoes.selecao;
        while(atual){
            if(contador)string+=',';
            string += atual.obj.getAttribute("id") + ';'+atual.codeCor+'/'+idGrafico;
            contador++;
            atual = atual.prox;
        }
        $('hiddenmatrizCanvasArranjo').value = string;
        ////alert('cliqueCanvas Arranjo= '+string);


        var string = "";
        var contador = 0;
        var atual = Propriedades.selecao;
        while(atual){
            if(contador)string+=',';
            string += atual.obj.getAttribute("zid") + ';'+atual.codeCor+'/'+idGrafico;
            contador++;
            atual = atual.prox;
        }
        $('hiddenmatrizCanvasArranjoprop').value = string;
        ////alert('cliqueCanvas prop= '+string);
        

        $('form').submit();

    }catch(err){
        //alert('Erro cliqueCanvas: '+err);
    }

}

function cliqueTipoGrafico(idCanvas,tipoGrafico){

        $('hiddentipoGrafico').value = idCanvas+','+tipoGrafico;
        //alert($('hiddentipoGrafico').value);
        $('form').submit();
}

//debug('canvas ok');