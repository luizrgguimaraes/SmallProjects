// JavaScript Document

class Cores{
        
        static getCor(){
            for(var i=0;i<Cores.count;i++){
                if(Cores.vetor[i].usada==false){
                    return i; 
                }
            } 
            debug('nao ha mais cores disponiveis');
        }                                  


        static addCor(corString){
        
                if(Cores.vetor == undefined){
                    Cores.vetor = [];
                }
            
               
                if(Cores.count == undefined){
                    Cores.count = 0;
                }
               
                Cores.vetor[Cores.count++] = new Cor(corString);
        
        }
    
        static liberarCor(codeCor){
            Cores.vetor[codeCor].liberar();
        }                                     
}

class Cor{
    constructor(corString){
        this.cor = corString;
        this.usada = false;
    }
    
    get(){
        this.usada = true;
        return this.cor;
    }
    
    liberar(){

        this.usada = false;

    }
}

