
////alert('javaScript OK');
/*
var Pizza = function(cor,percentualInicial,percentualAtual,raio){
    this.cor = cor;
    this.inicio = percentualInicial;
    this.fim = percentualInicial + percentualAtual;
    this.percentual = percentualAtual;
    this.raio = raio;
    this.x = 0;
    this.y = 0;
    
}

Pizza.prototype.desenhar = function(x,y){

    //alert('arquivo javascript');
    this.x = x;
    this.y = y;
    
    var inicio = this.inicio;
    var fim = this.fim;
    
    if(this.percentual>0.5 && this.percentual<1){
        //dividir em duas fatias para evitar anomalias
        desenharGrafico(this,this.inicio,this.inicio+0.5);
        desenharGrafico(this,this.inicio+0.49,this.fim); // 0.49 - corrige ranhura quando usamos 0.5 de inicio
    }else{
        desenharGrafico(this,this.inicio,this.fim);
    }
    
}

function desenharGrafico(Pizza, inicio, fim){
    var angF = (Math.PI/180) * 360 * fim;
    var angI = (Math.PI/180) * 360 * inicio;
    ctx.beginPath();
    ctx.fillStyle = Pizza.cor;
    ctx.strokeStyle = Pizza.cor;
    ctx.lineWidth = Pizza.raio;
    ctx.arc(Pizza.x,Pizza.y, Pizza.raio/2, -angF,-angI);
    ctx.stroke();
    ctx.fill();
} 

Pizza.prototype.desenharBordaFilho = function(inicio, fim,cor){

    //desenhar pizza com raio um pouco maior e cor do Pai
    var raio = raioMiniPizza(this.raio,this.percentual);
    var posicao = (this.percentual/2) + this.inicio; 
    var x = this.x + Math.cos(Math.PI/180 * (posicao) * 360)*(this.raio + raio);
    var y = this.y - Math.sin(Math.PI/180 * (posicao) * 360)*(this.raio + raio);
    if(cor==null)
        cor = this.cor
    
    var bordaMiniPizza = new Pizza(cor,inicio,fim,(raio*1.1));
    bordaMiniPizza.desenhar(x,y);
    
    
}




Pizza.prototype.desenharFilho = function(inicio,percentual,cor){

    var raio = raioMiniPizza(this.raio,this.percentual);
    var posicao = (this.percentual/2) + this.inicio; 
    var x = this.x + Math.cos(Math.PI/180 * (posicao) * 360)*(this.raio + raio);
    var y = this.y - Math.sin(Math.PI/180 * (posicao) * 360)*(this.raio + raio);
    //desenhar pizza com raio um pouco maior e cor do Pai
//    var bordaMiniPizza = new Pizza(this.cor,0,1,(this.raio*1.01));
//    bordaMiniPizza.desenhar(x,y);
    
    
    //desenhar fatia/
    var miniPizza = new Pizza(cor,inicio,percentual,raio);
    miniPizza.desenhar(x,y);    
    return miniPizza;
}

function raioMiniPizza(raioPai, percentual){
    var raioFilho = raioPai * Math.sqrt(percentual);
    return raioFilho; 
}



function enviarEstado() {
    var i = 0;
try{
    document.getElementById('hiddenTipoRegiao').value = 0; 
    document.getElementById('hiddenNomeRegiao').value=0;
    document.getElementById('hiddenEstado').value=document.getElementById('ComboEstado').selectedIndex;
    
}catch(err){
    //alert(err);
}
    document.getElementById('myForm').submit();
}



function enviar() {
    var i = 0;
try{

    //alert('ola mundo');
    var radios = document.getElementsByName('radioTipoRegiao');
    document.getElementById('hiddenTipoRegiao').value = 0;
    for(i =0;i<radios.length;i++){
        if(radios[i].checked){
            document.getElementById('hiddenTipoRegiao').value = i;
            break;
        }
    
    } 
    switch (i){
        case 0:
            document.getElementById('hiddenNomeRegiao').value=document.getElementById('ComboNomeMesorregiao').selectedIndex;
            break;
        case 1:
            document.getElementById('hiddenNomeRegiao').value=document.getElementById('ComboNomeMicrorregiao').selectedIndex;
            break;
        case 2:
            document.getElementById('hiddenNomeRegiao').value=document.getElementById('ComboNomeMunicipio').selectedIndex;
            break;
    }
    //alert('ola universo');
    document.getElementById('hiddenEstado').value=document.getElementById('ComboEstado').selectedIndex;
    
    
}catch(err){
    //alert('arquivojs - '+err);
}

    document.getElementById('myForm').submit();
}
*/

