// JavaScript Document
class Selecoes{

        static add(obj){
            try{
    
                if(Selecoes.selecao == undefined){
                    Selecoes.selecao = new Selecao(obj);
                }else{
                    if(!Selecoes.del(obj)){
                        new Selecao(obj);
                    }
                }
    
            }catch(err){alert('Erro addSelecao:'+err);}
        }
        
        static del(obj){
            try{
                if(Selecoes.selecao == undefined){
                      return false;
                }
                
                if(Selecoes.selecao.obj == obj){
                      var salvarprox = Selecoes.selecao.prox;
                      Selecoes.selecao.del(); 
                      delete(Selecoes.selecao);
                      if(salvarprox)Selecoes.selecao = salvarprox;
                      return true;
                }
                  
                var atual = Selecoes.selecao;
      
                while(atual.prox != null){
                        if(atual.prox.obj==obj){
                            atual.prox.del();
                            atual.prox = atual.prox.prox;
                            return true;
                        }else{
                          atual = atual.prox;
                        }
                }
      
                return false;
      
            }catch(err){alert('Erro delSelecao:'+err);}
        }
    
        static ultimaSelecao(){
            if(Selecoes.selecao == undefined){
                return null;
            }
        
            var atual = Selecoes.selecao; 
            while(atual.prox != null){
                atual = atual.prox;
            }      
            return atual;
        }   

}

class Selecao{

    constructor(obj){
        
        var ultimaSelecao = Selecoes.ultimaSelecao();
    
        this.obj = obj;
        this.codeCor = Cores.getCor(); 
        obj.style.backgroundColor = Cores.vetor[this.codeCor].get();
        this.prox = null;
        
        if(ultimaSelecao)ultimaSelecao.prox = this;
    }
    
    del(){

        Cores.liberarCor(this.codeCor);
        this.obj.style.backgroundColor = "";
    
    }    
    
    
}


function clique(obj){
    try{
        Selecoes.add(obj);
        
    }catch(err){
        //alert('Erro em selecionarTarefa(): '+err);
    }    

}

function moverObjeto(id,idCanvas,idCor,tipo,textolegenda){
    try{
        if(tipo == undefined)tipo = "";
        var clone = $(tipo+id).cloneNode(true);
        if(!clone){
            //alert('objeto a ser movido indefinido');
            return;
        }
        
        clone.style.backgroundColor = Cores.vetor[idCor].get();
        
        var canvas = $('canvasParametros'+idCanvas);
        if(canvas == undefined){
            //alert('objeto canvas nao encontrado');
            return;
        }
 
        var tr = document.createElement('tr');
        tr.appendChild(clone);
        
        var tdlegenda = document.createElement('td');
        tdlegenda.innerHTML = textolegenda; 
        
        var remove = document.createElement('td');
        remove.setAttribute('onclick','removeArranjoCanvas('+id+','+idCanvas+',"'+tipo+'")');
        ////alert(remove.getAttribute('onclick'));
        remove.innerHTML = '<button>X</button>';

        if(textolegenda)tr.appendChild(tdlegenda);
        tr.appendChild(remove);
        canvas.appendChild(tr);
        
    }catch(err){
        //alert('erro moverObjeto '+ err);
    }    
}

function removeArranjoCanvas(id, idCanvas,tipo){
        if(tipo == undefined)tipo = "";
        $('hiddenremoverObjetoCanvas'+tipo).value = id+','+idCanvas;
        $('form').submit();
}
////alert('movimento ok');