

var Pizza = function(ctx,cor,percentualInicial,percentualAtual,raio){

    try{
        this.cor = cor;
        this.inicio = percentualInicial;
        this.fim = percentualInicial + percentualAtual;
        this.percentual = percentualAtual;
        this.raio = raio;
        this.x = 0;
        this.y = 0;
        this.ctx = ctx;
    }catch(err){
        //alert('Erro new Pizza: '+err);
    }
}

Pizza.prototype.desenhar = function(x,y){


    
    this.x = x;
    this.y = y;
    try{    
        var inicio = this.inicio;
        var fim = this.fim;
        
        if(this.percentual>0.5 && this.percentual<1){
            //dividir em duas fatias para evitar anomalias
            desenharGrafico(this,this.inicio,this.inicio+0.5);
            desenharGrafico(this,this.inicio+0.49,this.fim); // 0.49 - corrige ranhura quando usamos 0.5 de inicio
        }else{
            desenharGrafico(this,this.inicio,this.fim);
        }

    }catch(err){
        //alert('Erro Pizza.desenhar: '+err);
    }


    
}

function desenharGrafico(Pizza, inicio, fim){
    try{    
        
        var angF = (Math.PI/180) * 360 * fim;
        var angI = (Math.PI/180) * 360 * inicio;
        var ctx = Pizza.ctx;
        var cor = Cores.vetor[Pizza.cor].get();

        ctx.beginPath();
        //ctx.fillStyle = Pizza.cor; 
        //ctx.strokeStyle = Pizza.cor;
        ctx.fillStyle = cor; 
        ctx.strokeStyle = cor;
        
        ctx.lineWidth = Pizza.raio;
        ctx.arc(Pizza.x,Pizza.y, Pizza.raio/2, -angF,-angI);
        ctx.stroke();
        ctx.fill();
    
    }catch(err){
        //alert('Erro desenhar Grafico: '+err);
    }

    
}


function rotulo(ctx,corId,valor,valorMax,marginLeft,text){
    try{    
        
        var cor = Cores.vetor[30].get();
        var altura = valor/valorMax*h*0.7;
        
        ctx.beginPath();
        ctx.fillStyle = cor; 
        ctx.strokeStyle = cor;
        ctx.font = "16px Arial";
        ctx.fillText(text, marginLeft, h - altura);
        ctx.strokeText(text, marginLeft, h - altura);
        ctx.lineWidth = 1;
        //ctx.fillRect(marginLeft,h - altura, 10,altura);
        //ctx.stroke();
        ctx.fill();
    
    }catch(err){
        //alert('Erro desenhar Barra: '+err);
    }

    
}

function desenharlinha(ctx,x,y){
    try{    
        //alert('desenharLinha');
        //var angF = (Math.PI/180) * 360 * fim;
        //var angI = (Math.PI/180) * 360 * inicio;
        
        //var cor = Cores.vetor[Pizza.cor].get();

        ctx.beginPath();
        //ctx.fillStyle = Pizza.cor; 
        //ctx.strokeStyle = Pizza.cor;
        //ctx.fillStyle = cor; 
        //ctx.strokeStyle = cor;
        
        //ctx.lineWidth = Pizza.raio;
        ctx.arc(x,y, 2, 0,2*Math.PI);
        ctx.arc(x,y, 2, 0,2*Math.PI);
        ctx.stroke();
        ctx.fill();
    
    }catch(err){
        //alert('Erro desenhar Grafico: '+err);
    }

    
}

function finalizarLinha(ctx){
        ctx.stroke();
        ctx.fill();
}



function desenharBarra(ctx,corId,valor,valorMax,marginLeft,largura){
    try{    
        
        var cor = Cores.vetor[corId].get();
        var altura = valor/valorMax*h*0.7;
        
        ctx.beginPath();
        ctx.fillStyle = cor; 
        ctx.strokeStyle = cor;
        ctx.lineWidth = 5;
        ctx.fillRect(marginLeft,h - altura, largura,altura);
        ctx.stroke();
        ctx.fill();
    
    }catch(err){
        //alert('Erro desenhar Barra: '+err);
    }

    
}
 
function desenharFundo(ctx,corId,marginLeft,largura){
    try{    
        var cor = Cores.vetor[corId].get();
        var altura = h;
        
        ctx.beginPath();
        ctx.fillStyle = cor; 
        ctx.strokeStyle = cor;
        ctx.lineWidth = 5;
        ctx.fillRect(marginLeft,0, largura,h);
        ctx.stroke();
        ctx.fill();
    
    }catch(err){
        //alert('Erro desenhar Barra: '+err);
    }

    
}

Pizza.prototype.desenharBordaFilho = function(inicio, fim,cor){

    //desenhar pizza com raio um pouco maior e cor do Pai
    var raio = raioMiniPizza(this.raio,this.percentual);
    var posicao = (this.percentual/2) + this.inicio; 
    var x = this.x + Math.cos(Math.PI/180 * (posicao) * 360)*(this.raio + raio);
    var y = this.y - Math.sin(Math.PI/180 * (posicao) * 360)*(this.raio + raio);
    if(cor==null)
        cor = this.cor
    
    var bordaMiniPizza = new Pizza(cor,inicio,fim,(raio*1.1));
    bordaMiniPizza.desenhar(x,y);
    
    
}




Pizza.prototype.desenharFilho = function(inicio,percentual,cor){

    var raio = raioMiniPizza(this.raio,this.percentual);
    var posicao = (this.percentual/2) + this.inicio; 
    var x = this.x + Math.cos(Math.PI/180 * (posicao) * 360)*(this.raio + raio);
    var y = this.y - Math.sin(Math.PI/180 * (posicao) * 360)*(this.raio + raio);
    //desenhar pizza com raio um pouco maior e cor do Pai
//    var bordaMiniPizza = new Pizza(this.cor,0,1,(this.raio*1.01));
//    bordaMiniPizza.desenhar(x,y);
    
    
    //desenhar fatia/
    var miniPizza = new Pizza(cor,inicio,percentual,raio);
    miniPizza.desenhar(x,y);    
    return miniPizza;
}

function raioMiniPizza(raioPai, percentual){
    var raioFilho = raioPai * Math.sqrt(percentual);
    return raioFilho; 
}


////alert('pizza ok');