// JavaScript Document
class Propriedades{

        static add(obj){
            try{
    
                if(Propriedades.selecao == undefined){
                    Propriedades.selecao = new Propriedade(obj);
                }else{
                    if(!Propriedades.del(obj)){
                        new Propriedade(obj);
                    }
                }
    
            }catch(err){alert('Erro addPropriedade:'+err);}
        }
        
        static del(obj){
            try{
                if(Propriedades.selecao == undefined){
                      return false;
                }
                
                if(Propriedades.selecao.obj == obj){
                      var salvarprox = Propriedades.selecao.prox;
                      Propriedades.selecao.del(); 
                      delete(Propriedades.selecao);
                      if(salvarprox)Propriedades.selecao = salvarprox;
                      return true;
                }
                  
                var atual = Propriedades.selecao;
      
                while(atual.prox != null){
                        if(atual.prox.obj==obj){
                            atual.prox.del();
                            atual.prox = atual.prox.prox;
                            return true;
                        }else{
                          atual = atual.prox;
                        }
                }
      
                return false;
      
            }catch(err){alert('Erro delPropriedade:'+err);}
        }
    
        static ultimaSelecao(){
            if(Propriedades.selecao == undefined){
                return null;
            }
        
            var atual = Propriedades.selecao; 
            while(atual.prox != null){
                atual = atual.prox;
            }      
            return atual;
        }   

}

class Propriedade{

    constructor(obj){
        
        var ultimaSelecao = Propriedades.ultimaSelecao();
    
        this.obj = obj;
        this.codeCor = Cores.getCor(); 
        obj.style.backgroundColor = Cores.vetor[this.codeCor].get();
        this.prox = null;
        
        if(ultimaSelecao)ultimaSelecao.prox = this;
    }
    
    del(){

        Cores.liberarCor(this.codeCor);
        this.obj.style.backgroundColor = "";
    
    }    
    
    
}


function cliquePropriedade(obj){
    try{
  
        Propriedades.add(obj);
        
    }catch(err){
        //alert('Erro em cliquePropriedade(): '+err);
    }    

}

////alert('propriedades ok');