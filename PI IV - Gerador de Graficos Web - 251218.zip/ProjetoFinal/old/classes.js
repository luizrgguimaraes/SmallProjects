////alert('classes.js OK');

/**/
const TIPO_SALVAR_SEM_ALTERACAO = 0, TIPO_SALVAR_ADICIONAR = 1, TIPO_SALVAR_EXCLUIR = 2, TIPO_SALVAR_ATUALIZAR = 3;
const HORASTATUS_PENDENTE = 0, HORASTATUS_OK = 1;


class ColecaoTarefas{

    static add(id,hora_id,tipoSalvar){
        try{        
            
            if(ColecaoTarefas.tarefa == undefined){

                ColecaoTarefas.tarefa = [];

            }
            
            if(ColecaoTarefas.tarefa[id] == undefined){

                ColecaoTarefas.tarefa[id] = new Tarefa(id);

            }else{

                return ColecaoTarefas.tarefa[id].addFilho(hora_id,tipoSalvar);
            }
        }catch(err){
            //alert('Erro em adicionarTarefa(): '+err);
        }
    }

    static del(id,subId){
        try{        
            
            if(ColecaoTarefas.tarefa == undefined){
                return false;
            }
            
            if(ColecaoTarefas.tarefa[id] == undefined){
                return false
            }else{
                ////alert('del('+subId+')');
                return ColecaoTarefas.tarefa[id].removerFilho(subId);
            }
        }catch(err){
            //alert('Erro em removerTarefa(): '+err);
        }
    }
    
    static getStringAlteracao(){
        
        try{
            if(ColecaoTarefas.stringAlteracao == undefined){
    
                    ColecaoTarefas.stringAlteracao = "0";
    
            }
            if(ColecaoTarefas.tarefa == undefined)return "";
    
            ColecaoTarefas.tarefa.forEach(function(item,index){ColecaoTarefas.stringAlteracao += item.getAlteracao();});
            
            return ColecaoTarefas.stringAlteracao;
            
        }catch(err){alert("Erro em ColecaoTarefas.getStringAlteracao() = "+err);}
    
    }

    static setHoraStatus(tarefa_id,hora_id,value){
        
        try{
            
            ColecaoTarefas.tarefa[tarefa_id].setHoraStatus(hora_id,value);
            
            return true;
            
        }catch(err){debug('Erro em ColecaoTarefas.setHoraStatus('+tarefa_id+','+hora_id+','+value+') = '+err);}
    
    }


}

class Tarefa{

    constructor(id,subId,tipoSalvar){
        this.id = id;
        this.subId = subId;
        
        $("pQtd"+id).innerHTML = (subId==undefined)? 0:subId;
        if(subId == undefined)this.subId = 0;
        this.descricao = null;
        this.tipo = null;
        this.nFilhos = 0;
        this.filho = null;
        this.tipoSalvar = tipoSalvar;
        if(tipoSalvar == undefined)this.tipoSalvar = 0;
        this.horaId = 0;
        this.horaStatus = 0;
        
    }

    addFilho(hora_id, tipoSalvar){
        

        var ultimofilho = ultimoListaEncadeada(this);
        ultimofilho.filho = new Tarefa(this.id,++this.nFilhos);
        
        if(tipoSalvar){
            ultimofilho.filho.tipoSalvar = TIPO_SALVAR_ADICIONAR;
        }
        ultimofilho.filho.horaId = hora_id;
        return this.nFilhos;

    }
    
    removerFilho(subIdRemover){

        try{
        
            ////alert('removerFilho('+subIdRemover+')');
            var objPai = anteriorListaEncadeada(this,subIdRemover);

            ////alert('objPai = '+objPai);
            if(objPai.filho.tipoSalvar == TIPO_SALVAR_SEM_ALTERACAO){
                objPai.filho.tipoSalvar = TIPO_SALVAR_EXCLUIR;
            }else{
                if(objPai){//existe tambem o filho
                    objPai.filho = objPai.filho.filho;
                }
            }
        }catch(err){alert('Erro em Tarefa.removerFilho(): '+err)}    
    }
    
    getText(){
        try{
            //debug(this.toString());
            
            var str = "id = "+this.id + " / subId = "+this.subId + " / horaId = "+this.horaId+" / tipo = "+this.tipo +" / nFilhos = "+this.nFilhos+" / filho = "+this.filho+' / horaStatus ='+this.horaStatus+' / tipoSalvar = '+this.tipoSalvar;//+(  (this.tipoSalvar==TIPO_SALVAR_SEM_ALTERACAO)?('Sem alteracao'): ((this.tipoSalvar==TIPO_SALVAR_ADICIONAR)?('Adicionar'):('Remover')));
            
            if(this.filho!=null){
                str += "<br>"+this.filho.getText();
            }
            return str;
            
        }catch(err){
            //alert("Erro em getText: "+err);
        }
    }
    
    getAlteracao(){
        try{
            var str = "";
            if(this.tipoSalvar){
                str = ","+this.tipoSalvar+"-"+this.id+":"+this.horaId+"/"+this.horaStatus;
            }
            if(this.filho!=null){
                str += this.filho.getAlteracao();
            }
            return str;
        }catch(err){
            //alert('Erro em Tarefa.getAlteracao(): '+err);
        }
        
    }
    
    setHoraStatus(hora_id,value){
        try{
            debug(this.getText());
            var tarefaHora = this.getTarefaDaHora(hora_id);
            tarefaHora.horaStatus = value;
            tarefaHora.tipoSalvar = TIPO_SALVAR_ATUALIZAR;
            debug(this.getText());
        }catch(err){
            //alert('Erro em Tarefa['+this.id+'].setHoraStatus('+hora_id+','+value+'): '+err);
        }
    }
    
    getTarefaDaHora(hora_id){
        if(this.horaId == hora_id)return this;
        if(this.filho == null)return null;
        return this.filho.getTarefaDaHora(hora_id);
    }
    
    
}




function ultimoListaEncadeada(tarefa){
    if(tarefa.filho == null)return tarefa;
    return ultimoListaEncadeada(tarefa.filho);
}

function anteriorListaEncadeada(obj,subId){
try{
    ////alert('anteriorListaEncadeada() = '+obj.getText());
    if(obj.filho == null){
        ////alert('anteriorListaEncadeada() - obj.filho = null');
        return null;
    }
    if(obj.filho.subId == subId)return obj;
    return anteriorListaEncadeada(obj.filho,subId);
}catch(err){
    //alert('Errom em anteriorListaEncadeada()'+err);
}
}
