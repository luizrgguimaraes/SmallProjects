<?php

class Tarefa{
    public $id;
    public $descricao;
    public $tipo;
    public $color;
    public $qtd;//quantidade de alocacoes - talvez seja melhor usar um contado interno no php para cada alocacao

    function Tarefa($resultSetLine){
            $this->id = $resultSetLine[0];
            $this->descricao = $resultSetLine[1];
            $this->tipo = $resultSetLine[2];
            $this->color = $resultSetLine[3];
            $this->qtd = 0; 
            ColecaoTarefa::$tarefasReferences[$this->id]=$this;
            ScriptFinal::add('ColecaoTarefas.add('.$this->id.');');
    }
}

class ScriptFinal{
    static $colecao;
    static function add($string){
        if(!isset(self::$colecao))self::$colecao = array();
        array_push(self::$colecao,$string);
    }

} 
class Tipo{
    public $id;
    public $descricao;
    public $meta;
    
    function Tipo($resultSetLine){
            $this->id = $resultSetLine[0];
            $this->descricao = $resultSetLine[1];
            $this->meta = $resultSetLine[2];
            ColecaoTipo::$tiposReferences[$this->id]=$this; 
    }
}

class Dia{
    public $id;
    public $hora;
    public $diaString;
    
    public function Dia($dia){
        $this->id = $dia;
        $this->hora = array();
        $this->criarMomentos($dia);
    }
    
    public function criarMomentos($dia){
        global $_diasSemana;
        global $_meses;
        
        $diaAtualStamp = getStampAtualDoCodigoDia($dia);  
        $this->diaString = $_diasSemana[date('w',$diaAtualStamp)].'<br>'.date('d',$diaAtualStamp);//' de '.$_meses[date('m',$diaAtualStamp)];
        
        $frequencia = 60/AGENDA_INTERVALOEMMINUTOS; 
        //$inicio = $dia * 24 * $frequencia + 1;
        //$fim = $inicio + 24 * $frequencia;
        
        //$inicio = $dia * 24 * $frequencia + 1;
        //$fim = $inicio + 24 * $frequencia;
        
        $intervalo = 24 * $frequencia;
        $fim = $dia * $intervalo;
        $inicio = $fim - $intervalo +1; 
        
        //debug('dia='.$dia.' - $frequencia = '.$frequencia.' - $inicio = '.$inicio.' - $fim = '.$fim);  
        for($i=$inicio;$i<$fim;$i++){
            $this->hora[$i]=new Hora($i);
            ColecaoHora::adicionarColecaoHoras($i,$this->hora[$i]);
        }
    }
}


class Hora{
    public $id;
    public $totalMinutos;
    public $diaInterno;
    public $hora;
    public $minuto;
    public $horaString;
    public $tarefa;
    
    function Hora($id){
        $this->id = $id;
        $this->totalMinutos = $id*AGENDA_INTERVALOEMMINUTOS;
        //$this->diaInterno = intdiv($id,60/AGENDA_INTERVALOEMMINUTOS*24);
        $this->hora = intdiv($this->totalMinutos,60)%24; 
        $this->minuto = $this->totalMinutos%60;
        $this->horaString = str_pad($this->hora,2,"0",STR_PAD_LEFT).':'.str_pad($this->minuto,2,"0",STR_PAD_LEFT);
        $this->tarefa = null;
    }
}

class Alocacao{
    public $id;
    public $tarefa_id;
    public $codigo_dia;
    public $codigo_hora;
    public $intervalo_hora;
    public $resultado_id;
      

    public function Alocacao($resultSetLine){
            $this->id = $resultSetLine['id'];
            $this->tarefa_id = $resultSetLine['tarefa_id'];
            ColecaoTarefa::$tarefasReferences[$this->tarefa_id]->qtd++;
            //debug(ColecaoTarefa::$tarefasReferences[$this->tarefa_id]->qtd);
            $this->codigo_dia = $resultSetLine['codigo_dia'];
            $this->codigo_hora = $resultSetLine['codigo_hora'];
            $this->intervalo_hora = $resultSetLine['intervalo_hora'];
            $this->resultado_id = $resultSetLine['resultado_id'];
            
    }
}

class ColecaoHora{
    static $horasReferences;
    public static function adicionarColecaoHoras($id,&$referenceHora){
        self::$horasReferences[$id] = &$referenceHora;
    }
}

class ColecaoTarefa{
    static $tarefasReferences;
    public static function add($id,$objeto){
        self::$tarefasReferences[$id] = $objeto;
    }
}

class ColecaoTipo{
    static $tiposReferences;
}


?>