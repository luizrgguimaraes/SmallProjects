// JavaScript Document

function selecionarTarefa(tarefa){
    try{
//        if(selecionarTarefa.tarefaSelecionada == tarefa){
//            delete selecionarTarefa.tarefaSelecionada;
//            tarefa.className = '';
//            return;
//        }
//comentado para manter tarefa selecionada
        selecionarTarefa.tarefaSelecionada = tarefa;
        //tarefa.className = 'selecionado';

    }catch(err){
        //alert('Erro em selecionarTarefa(): '+err);
    }    

}

function clique(obj){
    try{
        var objtipo = obj.getAttribute("tipo");
        switch(Number(objtipo)){
            case 0://tarefa nao alocada

                selecionarTarefa(obj);
                break;

            case 1://hora
                alocar(obj);                
                break;

            case 2://tarefa alocada
                selecionarTarefa(obj);
                break;

            default:
                //alert('clique - tipo do elemento indefinido');
                return;
        }

    }catch(err){
        //alert('Erro em selecionarTarefa(): '+err);
    }    

}

function alocar(hora){
    ////alert('alocar()');
    try{

        //se houver algum objeto selecionado
        if(!selecionarTarefa.tarefaSelecionada){
            debug('nenhum obj previamente selecionado -return');
            return;
        }
        //se nao tiver nenhuma tarefa alocada nesta hora
        if(hora.childElementCount>1){
            debug('hora ja tem tarefa alocada - return');
            return;
        }
        var tarefa = selecionarTarefa.tarefaSelecionada; 
        selecionarTarefa(selecionarTarefa.tarefaSelecionada);//deselecionar
        posicionar(tarefa,hora,TIPO_SALVAR_ADICIONAR);
        
        if(isAlocada(tarefa)){
            desalocar(tarefa);
        }
        
        
        //se objeto puder ter mais filhos ele deve continuar selecionado
        
        
    }catch(err){
        debug('Erro em alocar(): '+err);
    }    
}

function desalocar(btn){try{

    delete selecionarTarefa.tarefaSelecionada;//evitar que o mesmo clique aloque uma nova tarefa

    var tarefa_id = btn.getAttribute("zid");
    var tarefa_sid = btn.getAttribute("sid");
    
    var tarefa = $("btnTarefa"+tarefa_id+'-'+tarefa_sid)
    tarefa.parentNode.removeChild(tarefa);
    var ok = $("btnOk"+tarefa_id+'-'+tarefa_sid);
    ok.parentNode.removeChild(ok);
    var cancel = $("btnCancel"+tarefa_id+'-'+tarefa_sid);
    cancel.parentNode.removeChild(cancel);
    
    ////alert("btnTarefa"+tarefa_id+'-'+tarefa_sid);
    ColecaoTarefas.del(tarefa_id,tarefa_sid);

}catch(err){ alert('Erro em desalocar(): '+err); }
}

function posicionar(tarefa,hora,tipoSalvar){try{
    if(!hora)return;

    var tarefa_id = tarefa.getAttribute('zid');
    var hora_id = hora.getAttribute('zid');
    var novaIdBotao = ColecaoTarefas.add(tarefa_id,hora_id,tipoSalvar); //precisa mesmo de tipo salvar chegar como parametro de posicionar
    
    var cloneTarefa = tarefa.cloneNode(true);
    cloneTarefa.setAttribute("tipo",2);
    cloneTarefa.setAttribute("sid",novaIdBotao);
    cloneTarefa.setAttribute("id","btnTarefa"+tarefa_id+'-'+novaIdBotao);
    //var bkp = $('pQtd'+tarefa_id);
    //$('pQtd'+tarefa_id).parentNode.removeChild($('pQtd'+tarefa_id));

    hora.appendChild(cloneTarefa);
    hora.appendChild(novoBotaoConfirmar(tarefa_id,hora_id,novaIdBotao));
    hora.appendChild(novoBotaoDesalocar(tarefa_id,novaIdBotao));
    
//    imprimirColecao(ColecaoTarefas.tarefa);

}catch(err){debug('Erro em posicionar(): '+err); }
}

function posicionarJaSalvo(tarefa,hora,status){try{
    if(!hora)return false;
    if(!tarefa)return false;
    var tarefa_id = tarefa.getAttribute('zid');
    //debug(tarefa_id);
    var hora_id = hora.getAttribute('zid');
    var novaIdBotao = ColecaoTarefas.add(tarefa_id,hora_id);
    //debug('Nova idBotao = '+novaIdBotao);
    /*adicionar botao tarefa*/  
    var cloneTarefa = tarefa.cloneNode(true);
    cloneTarefa.setAttribute("tipo",2);
    cloneTarefa.setAttribute("sid",novaIdBotao);
    cloneTarefa.setAttribute("id","btnTarefa"+tarefa_id+'-'+novaIdBotao);
    //debug("btnTarefa"+tarefa_id+'-'+novaIdBotao);
    if(status)cloneTarefa.setAttribute("onclick","");
    hora.appendChild(cloneTarefa);

    if(status)return false;//nao foi definido status da tarefa ainda nesta hora
    hora.appendChild(novoBotaoConfirmar(tarefa_id,hora_id,novaIdBotao));
    hora.appendChild(novoBotaoDesalocar(tarefa_id,novaIdBotao));
    //debug('\''+hora.innerHTML+'\'');

}catch(err){alert('Erro em posicionarJaSalvo(): '+err); }
}

function novoBotaoConfirmar(tarefa_id,hora_id,tarefa_sid){
    var btn = document.createElement('button');
    btn.setAttribute('onclick','setStatusTarefaHora(this,'+HORASTATUS_OK+')');
    btn.setAttribute('zid',tarefa_id);
    btn.setAttribute('hora',hora_id);
    btn.setAttribute('sid',tarefa_sid);
    btn.setAttribute('id',"btnOk"+tarefa_id+'-'+tarefa_sid);
    btn.innerHTML = 'OK';
    return btn;
}

function novoBotaoDesalocar(tarefa_id,tarefa_sid){
    var btn = document.createElement('button');
    btn.setAttribute('onclick','desalocar(this)');
    btn.setAttribute('zid',tarefa_id);
    btn.setAttribute('sid',tarefa_sid);
    btn.setAttribute('id',"btnCancel"+tarefa_id+'-'+tarefa_sid);
    btn.innerHTML = ' X ';
    return btn;
}




function setStatusTarefaHora(btnStatusTarefaHora,value){
    try{
    
        tarefa_id = btnStatusTarefaHora.getAttribute('zid');
        hora_id = btnStatusTarefaHora.getAttribute('hora');
        ColecaoTarefas.setHoraStatus(tarefa_id,hora_id,value);


    
    }catch(err){debug('Erro em setStatusTarefaHora(): '+err); }
} 

function isAlocada(tarefa){
    if(tarefa.getAttribute('sid')>0){
        return true
    }
    return false;
}
 
function ocultarHora(hora_id){
try{
    var hora = $("trHora"+hora_id);
    hora.style.color = "red";
    hora.style.display = "none";
    //alert("ocultar hora "+hora_id);
    
}catch(err){debug('Erro em ocultarHora(): '+err); }
}  
////alert('movimento.js OK');