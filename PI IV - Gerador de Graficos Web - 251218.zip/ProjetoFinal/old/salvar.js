// JavaScript Document
//https://pt.stackoverflow.com/questions/41470/enviar-dados-do-formul%C3%A1rio-via-get-para-servidor-sem-atualizar-p%C3%A1gina
//https://pt.stackoverflow.com/questions/102050/enviar-formulario-sem-atualizar-a-pagina


function deletarTarefa(id){
    try{

        $('hiddenDeleteTarefa').value = id;

        $('form').submit();
    
    }catch(err){
        //alert('salvarNovaTarefa Erro: '+err);
    }
}

function salvarNovaTarefa(){
    try{

        var descricao = $('txtDescricao').value;
        var tipoTarefa = $('comboTipoTarefa').item($('comboTipoTarefa').selectedIndex).value;
        
        ////alert('tipo tarefa = '+tipoTarefa);

        $('hiddenDescricao').value = descricao;
        $('hiddenTipoTarefa').value = tipoTarefa;        
        $('hiddenAlteracaoAgenda').value = ColecaoTarefas.getStringAlteracao();
        
        
        $('form').submit();
    
    }catch(err){
        //alert('salvarNovaTarefa Erro: '+err);
    }
}

