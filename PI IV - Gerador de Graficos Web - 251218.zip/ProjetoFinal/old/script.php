<?php

function alocacoes(){
        $colecaoAlocacoes = consultarAlocacoes();
        foreach($colecaoAlocacoes as $id => $alocacao){
            /*Se o objeto hora nao foi criado ignoramos esta alocacao*/

            if(isset(ColecaoHora::$horasReferences[$alocacao->codigo_hora])){
                ColecaoHora::$horasReferences[$alocacao->codigo_hora]->tarefa = $alocacao->tarefa_id;
                ScriptFinal::add('posicionarJaSalvo($("btnTarefa'.$alocacao->tarefa_id.'"),$("trHora'.$alocacao->codigo_hora.'"),'.$alocacao->resultado_id.');');

                if($alocacao->resultado_id == ALOCACAOSTATUS_OK){
                    //ScriptFinal::add('fixarAlocacao('.$alocacao->codigo_hora.');');          
                
                }
            }
            
        }
}




?>