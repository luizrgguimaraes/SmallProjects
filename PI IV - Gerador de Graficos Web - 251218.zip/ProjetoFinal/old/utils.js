// JavaScript Document
function $(elid){ 

    try{

        var obj=document.getElementById(elid);

        if(obj){return obj;}else{

            ////alert('ELEMENTO NAO ENCONTRADO:'+elid);
        }

        return false;

    }catch(err){

        //alert('Error on $('+elid+'): '+err);

    }

}

function imprimirColecao(arrayObjetos){
    try{
        arrayObjetos.forEach(function(item,index){debug(item.getText())});
    }catch(err){
        //alert("Erro ao imprimir Colecao: "+err);
    
    }
}

function debug(str){
    try{
        var p = document.createElement("p");
        p.innerHTML = str;
        p.style = "font-size:16px;"
        document.getElementById("debug").appendChild(p);
    }catch(err){
        //alert('Erro em debug: '+err);
    }
} 
