<?php



class Arranjo{
    public $id;
    public $nome;
    public $populacao;
    public $urbano;
    public $rural;
    public $deslocamento;
    public $integracao;
    public $pib;
    public $percapita;
    public $agropecuaria;
    public $industria;
    public $servicosprivados;
    public $servicospublicos;
    public $impostos;
    public $empresas;
    public $unidades;
    public $color;
    public $prop;

    function Arranjo($resultSetLine,$posicao){
    
        //debug($posicao);
        $i=0;
        $this->id = $resultSetLine[$i++];
        $this->nome = $resultSetLine[$i++];
        $this->populacao = $resultSetLine[$i++];
        $this->prop[POPULACAO][1] = $this->populacao; 
        $this->urbano = $resultSetLine[$i++];
        //$this->prop[URBANO][1] = ($this->populacao*$this->urbano*0.01);
        $this->prop[URBANO][1] = ($this->urbano);

        $this->rural = $resultSetLine[$i++];
        //$this->prop[RURAL][1] = ($this->populacao*$this->rural*0.01);
        $this->prop[RURAL][1] = $this->populacao;
        $this->deslocamento = $resultSetLine[$i++];
        $this->prop[DESLOCAMENTO][1] = $this->deslocamento;
        $this->integracao = $resultSetLine[$i++];
        $this->pib = $resultSetLine[$i++];
        $this->prop[PIB][1] = $this->pib;
        $this->percapita = $resultSetLine[$i++];
        $this->agropecuaria = $resultSetLine[$i++];
        //$this->prop[AGROPECUARIA][1] = $this->agropecuaria*$this->pib*0.01;
        $this->prop[AGROPECUARIA][1] = $this->agropecuaria;
        $this->industria = $resultSetLine[$i++];
        //$this->prop[INDUSTRIA][1] = $this->industria*$this->pib*0.01;
        $this->prop[INDUSTRIA][1] = $this->industria;
        $this->servicosprivados = $resultSetLine[$i++];
        //$this->prop[SERVICOSPRIVADOS][1] = $this->servicosprivados*$this->pib*0.01;
        $this->prop[SERVICOSPRIVADOS][1] = $this->servicosprivados;
        $this->servicospublicos = $resultSetLine[$i++];
        //$this->prop[SERVICOSPUBLICOS][1] = $this->servicospublicos*$this->pib*0.01;
        $this->prop[SERVICOSPUBLICOS][1] = $this->servicospublicos;
        $this->impostos = $resultSetLine[$i++];
        //$this->prop[IMPOSTOS][1] = $this->impostos*$this->pib*0.01;
        $this->prop[IMPOSTOS][1] = $this->impostos;
        $this->empresas = $resultSetLine[$i++];
        $this->prop[EMPRESAS][1] = $this->empresas;
        $this->unidades = $resultSetLine[$i++];
        $this->prop[UNIDADES][1] = $this->unidades;
        
        
        if(isset($_SESSION['colorarranjo'][$this->id])){
            $this->color = $_SESSION['colorarranjo'][$this->id];
        }else{
            $this->color = -1;
        }

        Colecao::addArranjo($this,$posicao);

    }
}

class ScriptFinal{
    static $colecao;
    static function add($string){
        if(!isset(self::$colecao))self::$colecao = array();
        array_push(self::$colecao,$string);
    }

} 

class Colecao{
    static $arranjos;
    static $arranjosOrdenados;
    public static function addArranjo($obj,$posicao){
        if(!isset(self::$arranjos))self::$arranjos = array();
        if(!isset(self::$arranjosOrdenados))self::$arranjosOrdenados = array();
        self::$arranjos[$obj->id] = $obj;
        self::$arranjosOrdenados[$posicao] = $obj;
    }
    public static function getArranjo($id){
        if(isset(self::$arranjos[$id])){
            return self::$arranjos[$id];
        }
        return null;
    }
    public static function getArranjoOrdenado($pos){
        if(isset(self::$arranjosOrdenados[$pos])){
            return self::$arranjosOrdenados[$pos];
        }
        return null;
    }

}


?>