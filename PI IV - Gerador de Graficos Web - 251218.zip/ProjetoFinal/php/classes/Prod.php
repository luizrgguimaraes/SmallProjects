<?php

class Prod{
    public $id;
    public $colorId;
    public $descricao;
    
    function Prod($descricao){
        $this->descricao  = $descricao;
        
        
        $this->id = ColecaoProd::addProd($this); 
    
    }
    
    function setColor($colorId){
        $this->colorId = $colorId;
    }


}

class ColecaoProd{
    static $arrayProd;
    static $countProd;
    
    public static function addProd($objProd){
        if(!isset(self::$arrayProd))$arrayProd = array();
        if(!isset(self::$countProd)){
            $countProd = 0;
        }else{
            $countProd++;
        }
        
        $arrayProd[$countProd] = $objProd;
        return $countProd;
    }

}



?>