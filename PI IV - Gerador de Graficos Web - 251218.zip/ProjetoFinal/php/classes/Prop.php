<?php

class Prop{
    public $id;
    public $colorId;
    public $descricao;
    
    function Prop($id,$descricao){
        $this->descricao  = $descricao;
        $this->id = ColecaoProp::addProp($id,$this); 
    }
    
    function setColor($colorId){
        $this->colorId = $colorId;
    }


}

class ColecaoProp{
    static $arrayProp;
    static $countProp;
    
    public static function addProp($id,$objProp){
        if(!isset(self::$arrayProp))$arrayProp = array();
        /*if(!isset(self::$countProp)){
            $countProp = 0;
        }else{
            $countProp++;
        } */
        
        $arrayProp[$id] = $objProp;
        //return $countProp;
        return $id;
    }

}



?>