<?php

$cores = array(
    'rgb(47,79,79)' //DarkSlateGray
    ,'rgb(105,105,105)' //DimGrey
    ,'rgb(112,128,144)' //  SlateGrey
    ,'rgb(25,25,112)' //MidnightBlue
    ,'rgb(100,149,237)' //CornflowerBlue
    ,'rgb(72,61,139)' //DarkSlateBlue
    ,'rgb(188,143,143)' //RosyBrown
    ,'rgb(205,92,92)' //IndianRed - rosa mais escuro
    ,'rgb(222,184,135)' //Burlywood - marrom bem claro
    ,'rgb(139,69,19)' //SaddleBrown - marrom
    ,'rgb(85,26,139)' //Purple4 - roxo
    ,'rgb(85,107,47)' //DarkOliveGreen - Verde bem escuro
    ,'rgb(139,90,43)' //Marrom Claro
    ,'rgb(70,100,255)' //SteelBlue - azul escuro
    ,'rgb(175,238,238)' //PaleTurquoise - azul bem claro
    ,'rgb(220,220,220)' //Gainsboro - cinza claro
    ,'rgb(205,133,63)' //Peru - Marrom Claro
    ,'rgb(79,79,79)' //grey31 - cinza escuro 
    ,'rgb(143,188,143)' //DarkSeaGreen - verde bem claro
    ,'rgb(139,117,0)' //Gold4 - beji
    ,'rgb(205,133,63)' //Peru - Marrom Claro
    ,'rgb(255,255,255)' //branco - preto
    ,'rgb(255,0,0)' //Red - vermelho
    ,'rgb(255,255,0)' //Yellow - amarelo
    ,'rgb(255,69,0)' //OrangeRed - laranja
    ,'rgb(255,20,147)' //DeepPink - Rosa forte
    ,'rgb(0,0,139)' //Blue4 - azul bem escuro
    ,'rgb(124,252,0)' //LawnGreen - Verde brilhante
    ,'rgb(0,191,255)' //DeepSkyBlue - azul claro
    ,'rgb(46,139,87)' //SeaGreen - verde claro
    ,'rgb(0,100,0)' //DarkGreen - Verde Escuro
    ,'rgb(255,20,147)' //DeepPink - rosa escuro
    ,'rgb(238,201,0)' //Gold2 - amarelo forte
    ,'rgb(255,165,0)' //Orange - amarelo alaranjado
    ,'rgb(0,0,0)' //Orange - amarelo alaranjado
);


?>