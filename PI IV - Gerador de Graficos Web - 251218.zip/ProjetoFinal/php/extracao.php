<?php

function extrairDadosTab01(){
    $pathFile = "Data/tab01-utf8v3.csv";
    $file = fopen($pathFile,'r');
    
    $contador = 0;
    $id_arranjo = 1;
    
    while(!feof($file)) {
        
        $linha = fgets($file);
        
        
        $dados = explode(";",substr($linha,0,-1));//retira final de linha do ultimo campo
        $posPrimeiroParenteses = strpos($dados[0],'(');
        $posPrimeiraBarra = strpos($dados[0],'/');

        if(!$posPrimeiroParenteses){//Nao � Municipio e sim arranjo
            
            if($posPrimeiraBarra){//� arranjo
                                                    
                    $arranjoNome = substr($dados[0],0,$posPrimeiraBarra);
                    $id_arranjo = inserirArranjo($arranjoNome);
                    $contador++;
            }
            
        }else{ //nome de municipio
        
            $mun = array(
                ":nome" => substr($dados[0],0,$posPrimeiroParenteses-1) 
                ,":uf" => substr($dados[0],$posPrimeiroParenteses+1,2)
                ,":id_arranjo" => $id_arranjo
                ,":populacao" => $dados[2]
                ,":deslocamento" => $dados[4]
                ,":integracao" => $dados[5]
            );
        
            inserirMunicipio($mun);
            
        }
        //if($contador>=10)break;   
    }
    
    
}


function extrairDadosTab02(){
    $pathFile = "Data/tab02-utf8.csv";
    $file = fopen($pathFile,'r');
    
    $contador = 0;
    $id_arranjo = 1;
    
    while(!feof($file)) {
        
        $linha = fgets($file);
        
        
        $dados = explode(";",substr($linha,0,-1));//retira final de linha do ultimo campo
        $posPrimeiroParenteses = strpos($dados[0],'(');
        $posPrimeiraBarra = strpos($dados[0],'/');

        if(!$posPrimeiroParenteses){//Nao � Municipio e sim arranjo
            
            if($posPrimeiraBarra){//� arranjo
                                                    
                    $arrayParametros = array(
                        ':nome' => substr($dados[0],0,$posPrimeiraBarra)
                        ,':populacao' => $dados[2]
                        ,':urbano' => $dados[3]
                        ,':rural' => $dados[4]
                        ,':deslocamento' => $dados[9]
                        ,':integracao' => floatval($dados[11]) 
                    );

                    inserirDadosArranjoTab02($arrayParametros);
            }
            
        }

    }

}

function extrairDadosTab03(){
    $pathFile = "Data/tab03-utf8.csv";
    
    $file = fopen($pathFile,'r');
    
    
    $contador = 0;
    $id_arranjo = 1;
    
    while(!feof($file)) {
        
        $linha = fgets($file);
        
        
        $dados = explode(";",substr($linha,0,-2));//retira final de linha do ultimo campo
        $posPrimeiroParenteses = strpos($dados[0],'(');
        $posPrimeiraBarra = strpos($dados[0],'/');

        if(!$posPrimeiroParenteses){//Nao � Municipio e sim arranjo
            
            if($posPrimeiraBarra){//� arranjo
                                                    
                    $arrayParametros = array(
                        ':nome' => substr($dados[0],0,$posPrimeiraBarra)
                        ,':pib' => $dados[4]
                        ,':percapita' => $dados[5]
                        ,':agropecuaria' => $dados[6]
                        ,':industria' => $dados[7]
                        ,':servicosprivados' => $dados[8]
                        ,':servicospublicos' => $dados[9]
                        ,':impostos' => $dados[10]
                        ,':empresas' => $dados[11]
                        ,':unidades' => $dados[12]
                    );
                    //debug( print_r($arrayParametros,true) );
                    inserirDadosArranjoTab03($arrayParametros);
            }
            
        }

    }

}



?>