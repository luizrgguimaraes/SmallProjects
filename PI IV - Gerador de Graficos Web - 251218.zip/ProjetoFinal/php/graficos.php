<?php

function gerarGraficoPizzaPopulacao($arrayArranjos,$arrayPropriedades,$idCanvas){

    $canvasName = 'ctxPizzaPopulacao'.$idCanvas;
    
    $str = '
    try{
            if(ColecaoCanvas.vetor == undefined){
                ColecaoCanvas.add('.$idCanvas.');
            }
            
            if(ColecaoCanvas.vetor['.$idCanvas.'] == undefined){
                '.$canvasName.' = ColecaoCanvas.add('.$idCanvas.');
            } else{
                var '.$canvasName.' = ColecaoCanvas.vetor['.$idCanvas.'].ctx;
            }
        
    ';
    

//    $analise = analisarArranjos($arrayArranjos);
    
    $analises = analise($arrayArranjos,$arrayPropriedades,1);//tipo 1 - tipos numericos
    //$raioTotalAmostra = sqrt($analises["soma"]/pi());
    //$raioTotalAmostra = 60;
    $strlegenda = "";
    $larguraBarra = (W/(count($arrayArranjos)+1))/count($arrayPropriedades);
    if($larguraBarra>LARGURABARRAMAX){
        $larguraBarra = LARGURABARRAMAX;
    }

    $larguraFundo = W/count($arrayPropriedades);
    $distanciaEntreGraficos = $larguraBarra * (count($arrayArranjos)+1);
    $somap = 0;
    $contador = 0;    
    
    $i = 0;

    $tipoGrafico = getTipoGrafico($idCanvas);
    foreach($arrayPropriedades as $idp){
            $str.= 'moverObjeto("'.$idp.'",'.$idCanvas.','.$_SESSION['colorpropriedade'][$idp].',"prop");';
            //if($tipoGrafico==0)$str.='desenharFundo('.$canvasName.','.getPropColor($idp).','.($distanciaEntreGraficos*$i).','.($larguraFundo).');';
            if($tipoGrafico==1)break;//grafico de pizza so tem uma propriedade
            $i++;
    }
    $strrotulo = [];
    
    
    
    foreach($arrayArranjos as $id){
        $arranjoref = Colecao::$arranjos[$id];
        $strlegenda =  round($arranjoref->prop[POPULACAO][1]/1000000,3).' mi';
        
        foreach($arrayPropriedades as $key => $prop){
            if($tipoGrafico == 0){
                    switch($prop){
                        case (POPULACAO)://populacao
                            
                            $str.=  'desenharBarra('.$canvasName.','.($arranjoref->color).','.$arranjoref->prop[$prop][1].','.$analises["max"][$prop][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).','.$larguraBarra.');';
                            //$strrotulo[$prop] =  'rotulo('.$canvasName.','.($arranjoref->color).','.$arranjoref->prop[$prop][1].','.$analises["max"][$prop][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).',"Pop");';
                            break;            
                        case (URBANO): //pop urbana
                            $str.= 'desenharBarra('.$canvasName.','.($arranjoref->color).','.($arranjoref->prop[$prop][1]).','.$analises["max"][1][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).','.$larguraBarra.');';
                            break;            
                        case (RURAL): //pop rural
                            $str.= 'desenharBarra('.$canvasName.','.($arranjoref->color).','.($arranjoref->prop[$prop][1]).','.$analises["max"][1][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).','.$larguraBarra.');';
                            break;            
                        case (DESLOCAMENTO): //pop rural
                                                                                                                               //
                            $str.= 'desenharBarra('.$canvasName.','.($arranjoref->color).','.($arranjoref->prop[$prop][1]).','.$analises["max"][1][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).','.$larguraBarra.');';
                            break;            
                        case (PIB): //pop rural
                            $str.= 'desenharBarra('.$canvasName.','.($arranjoref->color).','.($arranjoref->prop[$prop][1]).','.$analises["max"][PIB][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).','.$larguraBarra.');';
                            break;            
                        case (AGROPECUARIA): //pop rural
                            $str.= 'desenharBarra('.$canvasName.','.($arranjoref->color).','.($arranjoref->prop[$prop][1]).','.$analises["max"][PIB][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).','.$larguraBarra.');';
                            break;            
                        case (INDUSTRIA): //pop rural
                            $str.= 'desenharBarra('.$canvasName.','.($arranjoref->color).','.($arranjoref->prop[$prop][1]).','.$analises["max"][PIB][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).','.$larguraBarra.');';
                            break;            
                        case (SERVICOSPRIVADOS): //pop rural
                            $str.= 'desenharBarra('.$canvasName.','.($arranjoref->color).','.($arranjoref->prop[$prop][1]).','.$analises["max"][PIB][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).','.$larguraBarra.');';
                            break;            
                        case (SERVICOSPUBLICOS): //pop rural
                            $str.= 'desenharBarra('.$canvasName.','.($arranjoref->color).','.($arranjoref->prop[$prop][1]).','.$analises["max"][PIB][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).','.$larguraBarra.');';
                            break;            
                        case (IMPOSTOS): //pop rural
                            $str.= 'desenharBarra('.$canvasName.','.($arranjoref->color).','.($arranjoref->prop[$prop][1]).','.$analises["max"][PIB][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).','.$larguraBarra.');';
                            break;            
                        case (EMPRESAS): //pop rural
                            $str.= 'desenharBarra('.$canvasName.','.($arranjoref->color).','.($arranjoref->prop[$prop][1]).','.$analises["max"][EMPRESAS][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).','.$larguraBarra.');';
                            break;            
                        case (UNIDADES): //pop rural
                            $str.= 'desenharBarra('.$canvasName.','.($arranjoref->color).','.($arranjoref->prop[$prop][1]).','.$analises["max"][EMPRESAS][1].','.(($distanciaEntreGraficos*$key)+($contador*$larguraBarra)).','.$larguraBarra.');';
                            break;            
                     
                                
                    }
            }elseif($tipoGrafico == 1){
                      if(!isset($acumulador[$prop]))$acumulador[$prop]=0;
                      $raioTotalAmostra = 50; 
                      $raioTotalAmostra = sqrt($analises["soma"][$prop][1]/pi());
                      $diminuidor = 1;
                      
                      while(($diminuidor*$raioTotalAmostra) > W/2){
                          $diminuidor-=0.01;
                      }
                      $raioTotalAmostra *= $diminuidor;
                      $raioTotalAmostra = W/2;
                      $str.='
                      var fatia = new Pizza('.$canvasName.','.($arranjoref->color).', '.$acumulador[$prop].', '.($perc = percentual($id,$analises["soma"][$prop][1])).','.$raioTotalAmostra.');
                      fatia.desenhar(w/2,w/2);
                      ';
                       
                      $acumulador[$prop] += $perc;
                      $strlegenda = round($perc*100,1).'%';
                      break;
            
            }elseif($tipoGrafico==2){
                    //$str.= 'desenharlinha('.$canvasName.',);';
                    
            }       
       
        
        }

        foreach($arrayPropriedades as $idp){
            if(isset($strrotulo[$idp])){
                $str.= $strrotulo[$idp];
            }
            
        }

            
            $str.= 'moverObjeto("'.$id.'",'.$idCanvas.','.($arranjoref->color).',undefined,"'.$strlegenda.'");';    
            

            $contador++; 
    }
    

    $str.= '}catch(err){alert(err);}';
    return $str;
}


function percentual($id,$total){

    $percentual = Colecao::$arranjos[$id]->populacao/$total;

    return $percentual; 


}

function analise($arrayAmostra,$arrayProp,$tipo){

    $max [][]=0;
    $soma[][]=0;
    
    $arrayProp = array(1,2,3,4,5,6,7,8,9,10,11,12);
    
        foreach($arrayAmostra as $id){
            foreach($arrayProp as $prop){
            
                if(!isset($soma[$prop][$tipo]))$soma[$prop][$tipo]=0;
                $soma[$prop][$tipo]+=Colecao::$arranjos[$id]->prop[$prop][$tipo];
                
                if(!isset($max[$prop][$tipo]))$max[$prop][$tipo]=0;
                if(Colecao::$arranjos[$id]->prop[$prop][$tipo] > $max[$prop][$tipo]){
                    $max[$prop][$tipo] = Colecao::$arranjos[$id]->prop[$prop][$tipo];
                }
            }
        }
    $result = array("max" => $max,"soma"=>$soma);
    return $result; 
        
}

function CalcularPearson($arrayPropriedades){

        $arrayArranjos = array();
        foreach(Colecao::$arranjosOrdenados as $key => $value){
            array_push($arrayArranjos,$key);        
        }
        
        //debug('Arranjos = '.print_r($arrayArranjos,true));
        //return;
        
        $media = array();
        $erro = array();
        foreach($arrayPropriedades as $prop){
            $count=0;
            
            foreach($arrayArranjos as $id){
                if(!isset($soma[$prop]))$soma[$prop]=0;
                $soma[$prop]+=Colecao::$arranjos[$id]->prop[$prop][1];
                $count++;
            }
            $media[$prop] = $soma[$prop]/$count;
        }
        //debug('MEDIA = '.print_r($media,true));
        



        foreach($arrayPropriedades as $prop){
            $i=0;
            foreach($arrayArranjos as $id){
                if(!isset($erro[$prop]))$erro[$prop]=array();
                if(!isset($erro[$prop][$id]))$erro[$prop][$id] = 0;
                $erro[$prop][$id]=Colecao::$arranjos[$id]->prop[$prop][1] - $media[$prop];
            }
        }                                                 
        //debug('ERRO = '.print_r($erro,true));



        foreach($arrayPropriedades as $prop){
            $i=0;
            foreach($arrayArranjos as $id){
                if(!isset($produtoErro[$id]))$produtoErro[$id] = 1;
                $produtoErro[$id]*=$erro[$prop][$id];
            }
        }                                                 
        //debug('$produtoErro = '.print_r($produtoErro,true));



        foreach($arrayArranjos as $id){
            if(!isset($somaProdutoErro))$somaProdutoErro = 0;
            $somaProdutoErro += $produtoErro[$id];
        }
        //debug('$somaProdutoErro = '.$somaProdutoErro);
        


        foreach($arrayPropriedades as $prop){
            $i=0;
            foreach($arrayArranjos as $id){
                $quadradoErro[$prop][$id]=$erro[$prop][$id]*$erro[$prop][$id];
            }
        }                                                 

        //debug('$quadradoErro = '.print_r($quadradoErro,true));


        foreach($arrayPropriedades as $prop){
            foreach($arrayArranjos as $id){
                if(!isset($somaQuadradoErro[$prop]))$somaQuadradoErro[$prop] = 0;
                $somaQuadradoErro[$prop] += $quadradoErro[$prop][$id];
            }
        }
        //debug('$somaQuadradoErro = '.print_r($somaQuadradoErro,true));


        foreach($arrayPropriedades as $prop){
                $raizSomaQuadradoErro[$prop] = sqrt($somaQuadradoErro[$prop]);
        }
        //debug('$raizSomaQuadradoErro = '.print_r($raizSomaQuadradoErro,true));
        
        
        foreach($arrayPropriedades as $prop){
                if(!isset($produtoRaizSomaQuadradoErro))$produtoRaizSomaQuadradoErro = 1;
                $produtoRaizSomaQuadradoErro*= $raizSomaQuadradoErro[$prop];
        }
        //debug('$produtoRaizSomaQuadradoErro = '.$produtoRaizSomaQuadradoErro);        
        
        
        $pearson = $somaProdutoErro/$produtoRaizSomaQuadradoErro;
        //debug('$pearson('.$arrayPropriedades[0].','.$arrayPropriedades[1].') = '.$pearson);
        return $pearson;
/*
        foreach($arrayProp as $prop){
            $i=0;
            foreach(Colecao::$arranjos as $id => $dados){
                if(!isset($somavariancia[$prop]))$somavariancia[$prop]=0;
                $somavariancia[$prop]+=($dados->prop[$prop][1]-$media[$prop])*($dados->prop[$prop][1]-$media[$prop]);
                if($i++>3)break;
            }
        }
        $raizsomavariancia = sqrt($somavariancia[$arrayProp[0]])*sqrt($somavariancia[$arrayProp[1]]);
        $pearson = $somaeProdutoErro/$raizsomavariancia;
        return $pearson;*/ 

}

  

function getTipoGrafico($idCanvas){
    if(isset($_SESSION["tipoGrafico"])){
        if(isset($_SESSION["tipoGrafico"][$idCanvas])){
            return $_SESSION["tipoGrafico"][$idCanvas];
        } 
    }
    return 0;
}            



?>