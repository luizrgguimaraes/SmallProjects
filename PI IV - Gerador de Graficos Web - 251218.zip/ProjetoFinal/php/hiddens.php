<?php

$_listaHiddens = array(
    "matrizCanvasArranjo"
    ,"matrizCanvasArranjoprop"
    ,"removerObjetoCanvas"
    ,"removerObjetoCanvasprop"
    ,"resetarPagina"
    ,"tipoGrafico"
);


function lerHiddens(){
global $_listaHiddens;
    $limparPost = 0;

    foreach($_listaHiddens as $hiddenName){
        if(isset($_GET['nm'.$hiddenName])){
                $_valoresGet['nm'.$hiddenName] = $_GET['nm'.$hiddenName];                            
        }
        if(!isset($_SESSION[$hiddenName]))$_SESSION[$hiddenName]=array(); 
    }
    
    
    if(isset($_valoresGet)){
        if(is_array($_valoresGet)){
            
            if(!empty($_valoresGet['nmresetarPagina'])){
 //               debug('resetarPagina');
                foreach($_SESSION as $key => $velue){
                    unset($_SESSION[$key]);
                }
                limparPost(1);
            }
            
            if(!empty($_valoresGet['nmtipoGrafico'])){
                debug('tipoGrafico');
                $items = explode(",",$_valoresGet['nmtipoGrafico']);
                $idCanvas = $items[0];
                $tipoGrafico = $items[1];
                $_SESSION["tipoGrafico"][$idCanvas] =  $tipoGrafico;
            }            
            
            
            
            extrairHiddenMatriz($_valoresGet,'matrizCanvasArranjo',"arranjo");  //Arranjp         
            extrairHiddenMatriz($_valoresGet,'matrizCanvasArranjoprop',"propriedade"); //propriedade           
            
            extrairHiddenRemove($_valoresGet,'removerObjetoCanvas',"arranjo","");
            extrairHiddenRemove($_valoresGet,'removerObjetoCanvasprop',"propriedade","prop");
            
            
            
            
        }
    }
    //limparPost($limparPost);
}

function extrairHiddenRemove($_valoresGet,$hidden,$tipo,$sufixo){
    if(!empty($_valoresGet['nm'.$hidden])){

        $items = explode(",",$_valoresGet['nm'.$hidden]);
        $id = $items[0];
        $canvas = $items[1]; 
        $arraydiff = array($id);
                                    
        if(isset($_SESSION['matrizCanvasArranjo'.$sufixo][$canvas])){
            $_SESSION['matrizCanvasArranjo'.$sufixo][$canvas] = array_diff($_SESSION['matrizCanvasArranjo'.$sufixo][$canvas],$arraydiff);
        }
            
        $removerCor = true;                              
        foreach($_SESSION['matrizCanvasArranjo'.$sufixo] as $canvas){
            foreach($canvas as $arranjo){
                if($arranjo == $id){
                    $removerCor = false;
                    break;
                }
            }
            if($removerCor)break;
        }
        if(!$removerCor)$_SESSION['color'.$tipo][$id] = -1;
        
    }
    
}

function extrairHiddenMatriz($_valoresGet,$hidden,$tipo){

            if(!empty($_valoresGet['nm'.$hidden])){

                    $items = explode(",",$_valoresGet['nm'.$hidden]);
                    foreach($items as $item){
                        $campos = explode(";",$item);
                        $id = $campos[0];
                        $campos2 = explode("/",$campos[1]);
                        $color = $campos2[0];
                        $_SESSION['color'.$tipo][$id] = $color;
                        $canvas = $campos2[1]; 
                        
                        $flagnovo = true;
                        if(isset($_SESSION[$hidden][$canvas])){
                            foreach($_SESSION[$hidden][$canvas] as $value){
                                if($value == $id){
                                    $flagnovo = false;
                                } 
                            }
                        }else{
                            $_SESSION[$hidden][$canvas]=array();
                        }
                        if($flagnovo)array_push($_SESSION[$hidden][$canvas],$id); 
                    }
            }


}

?>