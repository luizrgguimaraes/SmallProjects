<?php

//References
//https://docs.microsoft.com/en-us/sql/connect/php/step-1-configure-development-environment-for-php-development?view=sql-server-2017
//https://docs.microsoft.com/en-us/sql/connect/php/loading-the-php-sql-driver?view=sql-server-2017
//https://www.devmedia.com.br/conectando-no-sql-server-utilizando-pdo-em-php/38936
//https://docs.microsoft.com/pt-br/sql/connect/php/how-to-connect-using-windows-authentication?view=sql-server-2017
//https://github.com/Microsoft/msphpsql/releases
//http://php.net/manual/en/pdostatement.fetch.php

class Conexao
{
   private static $connection;
  
   private function __construct(){}
  
   public static function getConnection() {
  
       $pdoConfig  = DB_DRIVER . ":". "Server=" . DB_HOST . ";";
       $pdoConfig .= "Database=".DB_NAME.";";
       
       try {

           if(!isset($connection)){
                $opcoes = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
                $connection =  new PDO($pdoConfig, DB_USER, DB_PASSWORD,$opcoes);
           }

           return $connection;
       } catch (PDOException $e) {
           $mensagem = "Drivers disponiveis: " . implode(",", PDO::getAvailableDrivers());
           $mensagem .= "\nErro: " . $e->getMessage();
           throw new Exception($mensagem);
       }
   }
}

function limparTabelaArranjo(){
global $Conexao;
    try{
        $query  = $Conexao->query("delete from municipio");
        $query  = $Conexao->query("delete from arranjo");
        $query  = $Conexao->query("DBCC CHECKIDENT ('arranjo', reseed, 0);");
        $query  = $Conexao->query("DBCC CHECKIDENT ('municipio', reseed, 0);");

    }catch(Exception $e){
           debug( 'Erro ao inserirArranjo - '.$e->getMessage());
    }

}

function inserirMunicipio($parametros){
global $Conexao;
    try{
        $stringParametros = '';
        
        $flag = false;//s� inerir virgula de nao for o primeiro parametro
        foreach($parametros as $key => $value){
            if($flag)$stringParametros.=',';            
            $stringParametros.=$key;        -
            $flag = true;                
        } 
        
        $sql = "proc_inserirMunicipio ".$stringParametros;
        $stm = $Conexao->prepare($sql,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        
        $stm->execute($parametros);

    }catch(Exception $e){
           debug('Erro ao inserirMunicipio - "'.$parametros[':nome'].'" - '.$e->getMessage());
    }

}

function inserirDadosArranjoTab02($parametros){
global $Conexao;
    try{
        $stringParametros = '';

        $flag = false;//s� inerir virgula de nao for o primeiro parametro
        foreach($parametros as $key => $value){
            if($flag)$stringParametros.=',';            
            $stringParametros.=$key;        -
            $flag = true;                
        } 
        
        $sql = "proc_inserirDadosArranjoTab02 ".$stringParametros;
        $stm = $Conexao->prepare($sql,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        
        $stm->execute($parametros);

    }catch(Exception $e){
           debug('Erro ao proc_inserirDadosArranjoTab02 - "'.$parametros[':nome'].'" - '.$e->getMessage());
    }

}

function inserirDadosArranjoTab03($parametros){
global $Conexao;
    try{
        $stringParametros = '';

        $flag = false;//s� inerir virgula de nao for o primeiro parametro
        foreach($parametros as $key => $value){
            if($flag)$stringParametros.=',';            
            $stringParametros.=$key;        -
            $flag = true;                
        } 
        
        $sql = "proc_inserirDadosArranjoTab03 ".$stringParametros;
        $stm = $Conexao->prepare($sql,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        
        $stm->execute($parametros);

    }catch(Exception $e){
           debug('Erro ao proc_inserirDadosArranjoTab03 - "'.$parametros[':nome'].'" - '.$e->getMessage());
    }

}




function inserirArranjo($nome){
global $Conexao;
    try{
        //debug('inserirArranjo - '.$nome);
        $sql = "proc_inserirArranjo :nome";
        $stm = $Conexao->prepare($sql,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        //$stm->setAttribute(PDO::SQLSRV_ATTR_ENCODING, PDO::SQLSRV_ENCODING_SYSTEM);
        //$nome = iconv('Windows-1252', 'UTF-8', $nome);
        $stm->execute(array(':nome' => $nome));
        $result = $stm->fetch();
        
        
    
        return $result['id'];
        

    }catch(Exception $e){
           debug( 'Erro ao inserirArranjo - "'.$nome.'" - '.$e->getMessage());
    }

}



function consultarArranjo(){

global $Conexao;
    $objTarefa = array();
    try{
        $query   = $Conexao->query("proc_consultaArranjo");
        $recordSet = $query->fetchAll();
        $posicao = 1;
        foreach($recordSet as $key => $value){
                new Arranjo($value,$posicao);
                $posicao++;
        }
    }catch(Exception $e){
           echo 'Erro ao consultarArranjo() - '.$e->getMessage();
    }
}


?>

