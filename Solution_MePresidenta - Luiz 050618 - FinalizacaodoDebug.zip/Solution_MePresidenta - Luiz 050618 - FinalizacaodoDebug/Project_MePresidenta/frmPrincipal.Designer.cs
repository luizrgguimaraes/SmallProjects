﻿namespace Project_MePresidenta
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPrincipal));
            this.btnFechar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pbLogo = new System.Windows.Forms.PictureBox();
            this.painelLobby = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.labelNomePartidaSelecionada = new System.Windows.Forms.Label();
            this.lblDebugFileName = new System.Windows.Forms.Label();
            this.gbEntrarPartida = new System.Windows.Forms.GroupBox();
            this.btninfo = new System.Windows.Forms.Button();
            this.lblEntrarPartida = new System.Windows.Forms.Label();
            this.txtSenhadaPartidaEntrar = new System.Windows.Forms.TextBox();
            this.lblNomeJogador = new System.Windows.Forms.Label();
            this.lblSenhaPartida_Entrar = new System.Windows.Forms.Label();
            this.txtNomedoJogador = new System.Windows.Forms.TextBox();
            this.btnEntrarPartida = new System.Windows.Forms.Button();
            this.lblInformacaoDesenvolvido = new System.Windows.Forms.Label();
            this.gbCriarPartida = new System.Windows.Forms.GroupBox();
            this.lblCriarPartida = new System.Windows.Forms.Label();
            this.txtSenhaPartida = new System.Windows.Forms.TextBox();
            this.lblSenhaPartida_Criar = new System.Windows.Forms.Label();
            this.btnCriarPartida = new System.Windows.Forms.Button();
            this.txtNomedaPartida = new System.Windows.Forms.TextBox();
            this.lblNomePartida = new System.Windows.Forms.Label();
            this.lblIdPartida = new System.Windows.Forms.Label();
            this.btnAtualizar = new System.Windows.Forms.Button();
            this.lstPartidas = new System.Windows.Forms.ListView();
            this.chCodigo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chNomePartida = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chStatusPartida = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lblVersao = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.painelTabuleiro = new System.Windows.Forms.Panel();
            this.btnSairPartida = new System.Windows.Forms.Button();
            this.gbDesempregados = new System.Windows.Forms.GroupBox();
            this.btnd12 = new System.Windows.Forms.Button();
            this.btnd11 = new System.Windows.Forms.Button();
            this.btnd10 = new System.Windows.Forms.Button();
            this.btnd9 = new System.Windows.Forms.Button();
            this.btnd8 = new System.Windows.Forms.Button();
            this.btnd7 = new System.Windows.Forms.Button();
            this.btnd6 = new System.Windows.Forms.Button();
            this.btnd5 = new System.Windows.Forms.Button();
            this.btnd4 = new System.Windows.Forms.Button();
            this.btnd3 = new System.Windows.Forms.Button();
            this.btnd2 = new System.Windows.Forms.Button();
            this.btnd1 = new System.Windows.Forms.Button();
            this.btnd0 = new System.Windows.Forms.Button();
            this.btnConfiguracoes = new System.Windows.Forms.Button();
            this.btnIniciarPartida = new System.Windows.Forms.Button();
            this.gbVotacao = new System.Windows.Forms.GroupBox();
            this.btnNao = new System.Windows.Forms.Button();
            this.labelPerguntaVotacao = new System.Windows.Forms.Label();
            this.btnSim = new System.Windows.Forms.Button();
            this.gbPosicionamento = new System.Windows.Forms.GroupBox();
            this.txtPersonagem = new System.Windows.Forms.TextBox();
            this.txtSetor = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnPromover = new System.Windows.Forms.Button();
            this.btnPosicionar = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.gbJogadores = new System.Windows.Forms.GroupBox();
            this.labelVotacao5 = new System.Windows.Forms.Label();
            this.labelVotacao4 = new System.Windows.Forms.Label();
            this.labelVotacao3 = new System.Windows.Forms.Label();
            this.labelVotacao2 = new System.Windows.Forms.Label();
            this.labelVotacao1 = new System.Windows.Forms.Label();
            this.labelVotacao0 = new System.Windows.Forms.Label();
            this.j1 = new System.Windows.Forms.Button();
            this.j5 = new System.Windows.Forms.Button();
            this.j4 = new System.Windows.Forms.Button();
            this.j3 = new System.Windows.Forms.Button();
            this.lblPontos5 = new System.Windows.Forms.Label();
            this.lblPontos4 = new System.Windows.Forms.Label();
            this.lblPontos3 = new System.Windows.Forms.Label();
            this.lblPontos2 = new System.Windows.Forms.Label();
            this.lblPontos1 = new System.Windows.Forms.Label();
            this.lblJogadas5 = new System.Windows.Forms.Label();
            this.lblJogadas4 = new System.Windows.Forms.Label();
            this.lblJogadas3 = new System.Windows.Forms.Label();
            this.lblJogadas2 = new System.Windows.Forms.Label();
            this.lblJogadas1 = new System.Windows.Forms.Label();
            this.lblJogadas0 = new System.Windows.Forms.Label();
            this.lblPontos0 = new System.Windows.Forms.Label();
            this.j2 = new System.Windows.Forms.Button();
            this.nao53 = new System.Windows.Forms.Button();
            this.nao52 = new System.Windows.Forms.Button();
            this.nao51 = new System.Windows.Forms.Button();
            this.nao50 = new System.Windows.Forms.Button();
            this.nao43 = new System.Windows.Forms.Button();
            this.nao42 = new System.Windows.Forms.Button();
            this.nao41 = new System.Windows.Forms.Button();
            this.nao40 = new System.Windows.Forms.Button();
            this.nao33 = new System.Windows.Forms.Button();
            this.nao32 = new System.Windows.Forms.Button();
            this.nao31 = new System.Windows.Forms.Button();
            this.nao30 = new System.Windows.Forms.Button();
            this.nao23 = new System.Windows.Forms.Button();
            this.nao22 = new System.Windows.Forms.Button();
            this.nao21 = new System.Windows.Forms.Button();
            this.nao20 = new System.Windows.Forms.Button();
            this.nao13 = new System.Windows.Forms.Button();
            this.nao12 = new System.Windows.Forms.Button();
            this.nao11 = new System.Windows.Forms.Button();
            this.nao10 = new System.Windows.Forms.Button();
            this.nao03 = new System.Windows.Forms.Button();
            this.nao02 = new System.Windows.Forms.Button();
            this.nao01 = new System.Windows.Forms.Button();
            this.nao00 = new System.Windows.Forms.Button();
            this.j0 = new System.Windows.Forms.Button();
            this.lblNumRodada = new System.Windows.Forms.Label();
            this.lblPontuacaoTotal = new System.Windows.Forms.Label();
            this.lblPontuacaoAtual = new System.Windows.Forms.Label();
            this.lblRodada = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.n04 = new System.Windows.Forms.Button();
            this.n14 = new System.Windows.Forms.Button();
            this.n03 = new System.Windows.Forms.Button();
            this.n13 = new System.Windows.Forms.Button();
            this.n02 = new System.Windows.Forms.Button();
            this.n12 = new System.Windows.Forms.Button();
            this.n01 = new System.Windows.Forms.Button();
            this.n11 = new System.Windows.Forms.Button();
            this.n24 = new System.Windows.Forms.Button();
            this.n34 = new System.Windows.Forms.Button();
            this.n23 = new System.Windows.Forms.Button();
            this.n33 = new System.Windows.Forms.Button();
            this.n44 = new System.Windows.Forms.Button();
            this.n22 = new System.Windows.Forms.Button();
            this.n43 = new System.Windows.Forms.Button();
            this.n32 = new System.Windows.Forms.Button();
            this.n54 = new System.Windows.Forms.Button();
            this.n21 = new System.Windows.Forms.Button();
            this.n42 = new System.Windows.Forms.Button();
            this.n31 = new System.Windows.Forms.Button();
            this.n53 = new System.Windows.Forms.Button();
            this.n41 = new System.Windows.Forms.Button();
            this.n52 = new System.Windows.Forms.Button();
            this.n51 = new System.Windows.Forms.Button();
            this.n10 = new System.Windows.Forms.Button();
            this.btnAutoJogo = new System.Windows.Forms.Button();
            this.btnAlg5 = new System.Windows.Forms.Button();
            this.btnAlg7 = new System.Windows.Forms.Button();
            this.btnAlg4 = new System.Windows.Forms.Button();
            this.btnAlg3 = new System.Windows.Forms.Button();
            this.btnAlg2 = new System.Windows.Forms.Button();
            this.btnAlg1 = new System.Windows.Forms.Button();
            this.btnAlg0 = new System.Windows.Forms.Button();
            this.lblArquivoDebug = new System.Windows.Forms.Label();
            this.lblErro = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.gbConfiguracoes = new System.Windows.Forms.GroupBox();
            this.btnSomenteAtualizarTabuleiro = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.btnEntrarPartidaEmergencia = new System.Windows.Forms.Button();
            this.txtSenhaPartidaEmergencia = new System.Windows.Forms.TextBox();
            this.txtIdPartidaEmergencia = new System.Windows.Forms.TextBox();
            this.lblSenhaPartidaEmergencia = new System.Windows.Forms.Label();
            this.lblIdPartidaEmergencia = new System.Windows.Forms.Label();
            this.lblSenhaJogadorEmergencia = new System.Windows.Forms.Label();
            this.lblTempoSicronizacao = new System.Windows.Forms.Label();
            this.lblIdJogadorEmergencia = new System.Windows.Forms.Label();
            this.txtSenhaJogadorEmergencia = new System.Windows.Forms.TextBox();
            this.txtIdJogadorEmergencia = new System.Windows.Forms.TextBox();
            this.btnHabilitarDebug = new System.Windows.Forms.Button();
            this.btnAlg13 = new System.Windows.Forms.Button();
            this.btnAlg10 = new System.Windows.Forms.Button();
            this.btnTimer = new System.Windows.Forms.Button();
            this.btnHabilitarTimer = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtdebug = new System.Windows.Forms.TextBox();
            this.btnMinimizar = new System.Windows.Forms.Button();
            this.labelIndicadordeErro = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).BeginInit();
            this.painelLobby.SuspendLayout();
            this.gbEntrarPartida.SuspendLayout();
            this.gbCriarPartida.SuspendLayout();
            this.painelTabuleiro.SuspendLayout();
            this.gbDesempregados.SuspendLayout();
            this.gbVotacao.SuspendLayout();
            this.gbPosicionamento.SuspendLayout();
            this.gbJogadores.SuspendLayout();
            this.gbConfiguracoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnFechar
            // 
            this.btnFechar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFechar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFechar.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechar.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.btnFechar.Location = new System.Drawing.Point(436, 12);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(32, 32);
            this.btnFechar.TabIndex = 8;
            this.btnFechar.Text = "X";
            this.btnFechar.UseVisualStyleBackColor = false;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            this.btnFechar.MouseLeave += new System.EventHandler(this.btnFechar_MouseLeave);
            this.btnFechar.MouseHover += new System.EventHandler(this.btnFechar_MouseHover);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label1.Location = new System.Drawing.Point(192, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "Me Presidenta";
            // 
            // pbLogo
            // 
            this.pbLogo.BackColor = System.Drawing.Color.Transparent;
            this.pbLogo.Image = ((System.Drawing.Image)(resources.GetObject("pbLogo.Image")));
            this.pbLogo.Location = new System.Drawing.Point(84, 15);
            this.pbLogo.Name = "pbLogo";
            this.pbLogo.Size = new System.Drawing.Size(100, 67);
            this.pbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLogo.TabIndex = 10;
            this.pbLogo.TabStop = false;
            // 
            // painelLobby
            // 
            this.painelLobby.Controls.Add(this.label4);
            this.painelLobby.Controls.Add(this.labelNomePartidaSelecionada);
            this.painelLobby.Controls.Add(this.lblDebugFileName);
            this.painelLobby.Controls.Add(this.gbEntrarPartida);
            this.painelLobby.Controls.Add(this.gbCriarPartida);
            this.painelLobby.Controls.Add(this.lblIdPartida);
            this.painelLobby.Controls.Add(this.btnAtualizar);
            this.painelLobby.Controls.Add(this.lstPartidas);
            this.painelLobby.Location = new System.Drawing.Point(13, 101);
            this.painelLobby.Name = "painelLobby";
            this.painelLobby.Size = new System.Drawing.Size(454, 560);
            this.painelLobby.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label4.Location = new System.Drawing.Point(3, 310);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(172, 21);
            this.label4.TabIndex = 29;
            this.label4.Text = "Partida Selecionada:";
            // 
            // labelNomePartidaSelecionada
            // 
            this.labelNomePartidaSelecionada.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelNomePartidaSelecionada.AutoSize = true;
            this.labelNomePartidaSelecionada.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNomePartidaSelecionada.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.labelNomePartidaSelecionada.Location = new System.Drawing.Point(215, 310);
            this.labelNomePartidaSelecionada.Name = "labelNomePartidaSelecionada";
            this.labelNomePartidaSelecionada.Size = new System.Drawing.Size(100, 21);
            this.labelNomePartidaSelecionada.TabIndex = 28;
            this.labelNomePartidaSelecionada.Text = "(Nenhuma)";
            // 
            // lblDebugFileName
            // 
            this.lblDebugFileName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDebugFileName.AutoSize = true;
            this.lblDebugFileName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDebugFileName.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblDebugFileName.Location = new System.Drawing.Point(3, 308);
            this.lblDebugFileName.Name = "lblDebugFileName";
            this.lblDebugFileName.Size = new System.Drawing.Size(0, 21);
            this.lblDebugFileName.TabIndex = 27;
            this.lblDebugFileName.Visible = false;
            // 
            // gbEntrarPartida
            // 
            this.gbEntrarPartida.Controls.Add(this.btninfo);
            this.gbEntrarPartida.Controls.Add(this.lblEntrarPartida);
            this.gbEntrarPartida.Controls.Add(this.txtSenhadaPartidaEntrar);
            this.gbEntrarPartida.Controls.Add(this.lblNomeJogador);
            this.gbEntrarPartida.Controls.Add(this.lblSenhaPartida_Entrar);
            this.gbEntrarPartida.Controls.Add(this.txtNomedoJogador);
            this.gbEntrarPartida.Controls.Add(this.btnEntrarPartida);
            this.gbEntrarPartida.Controls.Add(this.lblInformacaoDesenvolvido);
            this.gbEntrarPartida.Location = new System.Drawing.Point(230, 342);
            this.gbEntrarPartida.Name = "gbEntrarPartida";
            this.gbEntrarPartida.Size = new System.Drawing.Size(221, 215);
            this.gbEntrarPartida.TabIndex = 26;
            this.gbEntrarPartida.TabStop = false;
            // 
            // btninfo
            // 
            this.btninfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btninfo.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btninfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btninfo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btninfo.Location = new System.Drawing.Point(190, 178);
            this.btninfo.Name = "btninfo";
            this.btninfo.Size = new System.Drawing.Size(25, 31);
            this.btninfo.TabIndex = 30;
            this.btninfo.Text = "?";
            this.btninfo.UseVisualStyleBackColor = false;
            this.btninfo.Click += new System.EventHandler(this.btninfo_Click);
            // 
            // lblEntrarPartida
            // 
            this.lblEntrarPartida.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblEntrarPartida.AutoSize = true;
            this.lblEntrarPartida.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntrarPartida.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblEntrarPartida.Location = new System.Drawing.Point(21, 19);
            this.lblEntrarPartida.Name = "lblEntrarPartida";
            this.lblEntrarPartida.Size = new System.Drawing.Size(181, 25);
            this.lblEntrarPartida.TabIndex = 18;
            this.lblEntrarPartida.Text = "Entrar na Partida";
            this.lblEntrarPartida.Visible = false;
            // 
            // txtSenhadaPartidaEntrar
            // 
            this.txtSenhadaPartidaEntrar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSenhadaPartidaEntrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.txtSenhadaPartidaEntrar.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtSenhadaPartidaEntrar.Location = new System.Drawing.Point(8, 139);
            this.txtSenhadaPartidaEntrar.MaxLength = 10;
            this.txtSenhadaPartidaEntrar.Name = "txtSenhadaPartidaEntrar";
            this.txtSenhadaPartidaEntrar.Size = new System.Drawing.Size(205, 26);
            this.txtSenhadaPartidaEntrar.TabIndex = 5;
            this.txtSenhadaPartidaEntrar.UseSystemPasswordChar = true;
            this.txtSenhadaPartidaEntrar.Visible = false;
            // 
            // lblNomeJogador
            // 
            this.lblNomeJogador.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNomeJogador.AutoSize = true;
            this.lblNomeJogador.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeJogador.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblNomeJogador.Location = new System.Drawing.Point(4, 58);
            this.lblNomeJogador.Name = "lblNomeJogador";
            this.lblNomeJogador.Size = new System.Drawing.Size(156, 21);
            this.lblNomeJogador.TabIndex = 17;
            this.lblNomeJogador.Text = "Nome do Jogador:";
            this.lblNomeJogador.Visible = false;
            // 
            // lblSenhaPartida_Entrar
            // 
            this.lblSenhaPartida_Entrar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSenhaPartida_Entrar.AutoSize = true;
            this.lblSenhaPartida_Entrar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSenhaPartida_Entrar.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblSenhaPartida_Entrar.Location = new System.Drawing.Point(4, 115);
            this.lblSenhaPartida_Entrar.Name = "lblSenhaPartida_Entrar";
            this.lblSenhaPartida_Entrar.Size = new System.Drawing.Size(150, 21);
            this.lblSenhaPartida_Entrar.TabIndex = 16;
            this.lblSenhaPartida_Entrar.Text = "Senha da Partida:";
            this.lblSenhaPartida_Entrar.Visible = false;
            // 
            // txtNomedoJogador
            // 
            this.txtNomedoJogador.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNomedoJogador.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.txtNomedoJogador.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtNomedoJogador.Location = new System.Drawing.Point(7, 83);
            this.txtNomedoJogador.MaxLength = 10;
            this.txtNomedoJogador.Name = "txtNomedoJogador";
            this.txtNomedoJogador.Size = new System.Drawing.Size(206, 26);
            this.txtNomedoJogador.TabIndex = 4;
            this.txtNomedoJogador.Visible = false;
            // 
            // btnEntrarPartida
            // 
            this.btnEntrarPartida.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnEntrarPartida.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnEntrarPartida.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEntrarPartida.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEntrarPartida.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnEntrarPartida.Location = new System.Drawing.Point(4, 178);
            this.btnEntrarPartida.Name = "btnEntrarPartida";
            this.btnEntrarPartida.Size = new System.Drawing.Size(184, 31);
            this.btnEntrarPartida.TabIndex = 6;
            this.btnEntrarPartida.Text = "Entrar na Partida";
            this.btnEntrarPartida.UseVisualStyleBackColor = false;
            this.btnEntrarPartida.Visible = false;
            this.btnEntrarPartida.Click += new System.EventHandler(this.btnEntrarPartida_Click);
            // 
            // lblInformacaoDesenvolvido
            // 
            this.lblInformacaoDesenvolvido.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblInformacaoDesenvolvido.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformacaoDesenvolvido.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblInformacaoDesenvolvido.Location = new System.Drawing.Point(6, 15);
            this.lblInformacaoDesenvolvido.Name = "lblInformacaoDesenvolvido";
            this.lblInformacaoDesenvolvido.Size = new System.Drawing.Size(214, 192);
            this.lblInformacaoDesenvolvido.TabIndex = 22;
            this.lblInformacaoDesenvolvido.Text = resources.GetString("lblInformacaoDesenvolvido.Text");
            this.lblInformacaoDesenvolvido.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // gbCriarPartida
            // 
            this.gbCriarPartida.Controls.Add(this.lblCriarPartida);
            this.gbCriarPartida.Controls.Add(this.txtSenhaPartida);
            this.gbCriarPartida.Controls.Add(this.lblSenhaPartida_Criar);
            this.gbCriarPartida.Controls.Add(this.btnCriarPartida);
            this.gbCriarPartida.Controls.Add(this.txtNomedaPartida);
            this.gbCriarPartida.Controls.Add(this.lblNomePartida);
            this.gbCriarPartida.Location = new System.Drawing.Point(3, 342);
            this.gbCriarPartida.Name = "gbCriarPartida";
            this.gbCriarPartida.Size = new System.Drawing.Size(221, 215);
            this.gbCriarPartida.TabIndex = 25;
            this.gbCriarPartida.TabStop = false;
            // 
            // lblCriarPartida
            // 
            this.lblCriarPartida.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCriarPartida.AutoSize = true;
            this.lblCriarPartida.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCriarPartida.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblCriarPartida.Location = new System.Drawing.Point(42, 19);
            this.lblCriarPartida.Name = "lblCriarPartida";
            this.lblCriarPartida.Size = new System.Drawing.Size(139, 25);
            this.lblCriarPartida.TabIndex = 12;
            this.lblCriarPartida.Text = "Criar Partida";
            // 
            // txtSenhaPartida
            // 
            this.txtSenhaPartida.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSenhaPartida.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.txtSenhaPartida.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtSenhaPartida.Location = new System.Drawing.Point(10, 139);
            this.txtSenhaPartida.MaxLength = 10;
            this.txtSenhaPartida.Name = "txtSenhaPartida";
            this.txtSenhaPartida.Size = new System.Drawing.Size(205, 26);
            this.txtSenhaPartida.TabIndex = 2;
            this.txtSenhaPartida.UseSystemPasswordChar = true;
            // 
            // lblSenhaPartida_Criar
            // 
            this.lblSenhaPartida_Criar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSenhaPartida_Criar.AutoSize = true;
            this.lblSenhaPartida_Criar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSenhaPartida_Criar.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblSenhaPartida_Criar.Location = new System.Drawing.Point(6, 115);
            this.lblSenhaPartida_Criar.Name = "lblSenhaPartida_Criar";
            this.lblSenhaPartida_Criar.Size = new System.Drawing.Size(150, 21);
            this.lblSenhaPartida_Criar.TabIndex = 10;
            this.lblSenhaPartida_Criar.Text = "Senha da Partida:";
            // 
            // btnCriarPartida
            // 
            this.btnCriarPartida.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCriarPartida.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnCriarPartida.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCriarPartida.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCriarPartida.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnCriarPartida.Location = new System.Drawing.Point(6, 178);
            this.btnCriarPartida.Name = "btnCriarPartida";
            this.btnCriarPartida.Size = new System.Drawing.Size(209, 31);
            this.btnCriarPartida.TabIndex = 3;
            this.btnCriarPartida.Text = "Criar Partida";
            this.btnCriarPartida.UseVisualStyleBackColor = false;
            this.btnCriarPartida.Click += new System.EventHandler(this.btnCriarPartida_Click);
            // 
            // txtNomedaPartida
            // 
            this.txtNomedaPartida.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNomedaPartida.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.txtNomedaPartida.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtNomedaPartida.Location = new System.Drawing.Point(9, 83);
            this.txtNomedaPartida.MaxLength = 10;
            this.txtNomedaPartida.Name = "txtNomedaPartida";
            this.txtNomedaPartida.Size = new System.Drawing.Size(206, 26);
            this.txtNomedaPartida.TabIndex = 1;
            // 
            // lblNomePartida
            // 
            this.lblNomePartida.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNomePartida.AutoSize = true;
            this.lblNomePartida.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePartida.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblNomePartida.Location = new System.Drawing.Point(6, 58);
            this.lblNomePartida.Name = "lblNomePartida";
            this.lblNomePartida.Size = new System.Drawing.Size(148, 21);
            this.lblNomePartida.TabIndex = 11;
            this.lblNomePartida.Text = "Nome da Partida:";
            // 
            // lblIdPartida
            // 
            this.lblIdPartida.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblIdPartida.AutoSize = true;
            this.lblIdPartida.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdPartida.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblIdPartida.Location = new System.Drawing.Point(181, 311);
            this.lblIdPartida.Name = "lblIdPartida";
            this.lblIdPartida.Size = new System.Drawing.Size(19, 21);
            this.lblIdPartida.TabIndex = 24;
            this.lblIdPartida.Text = "0";
            // 
            // btnAtualizar
            // 
            this.btnAtualizar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAtualizar.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAtualizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAtualizar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtualizar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnAtualizar.Location = new System.Drawing.Point(361, 306);
            this.btnAtualizar.Name = "btnAtualizar";
            this.btnAtualizar.Size = new System.Drawing.Size(90, 33);
            this.btnAtualizar.TabIndex = 14;
            this.btnAtualizar.Text = "Atualizar";
            this.btnAtualizar.UseVisualStyleBackColor = false;
            this.btnAtualizar.Click += new System.EventHandler(this.btnAtualizar_Click);
            // 
            // lstPartidas
            // 
            this.lstPartidas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chCodigo,
            this.chNomePartida,
            this.chStatusPartida});
            this.lstPartidas.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstPartidas.FullRowSelect = true;
            this.lstPartidas.Location = new System.Drawing.Point(3, 3);
            this.lstPartidas.Name = "lstPartidas";
            this.lstPartidas.Size = new System.Drawing.Size(448, 290);
            this.lstPartidas.TabIndex = 13;
            this.lstPartidas.UseCompatibleStateImageBehavior = false;
            this.lstPartidas.View = System.Windows.Forms.View.Details;
            this.lstPartidas.SelectedIndexChanged += new System.EventHandler(this.lstPartidas_SelectedIndexChanged);
            this.lstPartidas.DoubleClick += new System.EventHandler(this.lstPartidas_DoubleClick);
            // 
            // chCodigo
            // 
            this.chCodigo.Text = "";
            // 
            // chNomePartida
            // 
            this.chNomePartida.Text = "Nome da Partida";
            this.chNomePartida.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.chNomePartida.Width = 267;
            // 
            // chStatusPartida
            // 
            this.chStatusPartida.Text = "Status";
            this.chStatusPartida.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.chStatusPartida.Width = 100;
            // 
            // lblVersao
            // 
            this.lblVersao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblVersao.AutoSize = true;
            this.lblVersao.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersao.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblVersao.Location = new System.Drawing.Point(263, 681);
            this.lblVersao.Name = "lblVersao";
            this.lblVersao.Size = new System.Drawing.Size(209, 16);
            this.lblVersao.TabIndex = 12;
            this.lblVersao.Text = "MePresidentaServidor.dll | Versão 5.0";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // painelTabuleiro
            // 
            this.painelTabuleiro.Controls.Add(this.btnSairPartida);
            this.painelTabuleiro.Controls.Add(this.gbDesempregados);
            this.painelTabuleiro.Controls.Add(this.btnConfiguracoes);
            this.painelTabuleiro.Controls.Add(this.btnIniciarPartida);
            this.painelTabuleiro.Controls.Add(this.gbVotacao);
            this.painelTabuleiro.Controls.Add(this.gbPosicionamento);
            this.painelTabuleiro.Controls.Add(this.gbJogadores);
            this.painelTabuleiro.Controls.Add(this.lblNumRodada);
            this.painelTabuleiro.Controls.Add(this.lblPontuacaoTotal);
            this.painelTabuleiro.Controls.Add(this.lblPontuacaoAtual);
            this.painelTabuleiro.Controls.Add(this.lblRodada);
            this.painelTabuleiro.Controls.Add(this.label2);
            this.painelTabuleiro.Controls.Add(this.label3);
            this.painelTabuleiro.Controls.Add(this.n04);
            this.painelTabuleiro.Controls.Add(this.n14);
            this.painelTabuleiro.Controls.Add(this.n03);
            this.painelTabuleiro.Controls.Add(this.n13);
            this.painelTabuleiro.Controls.Add(this.n02);
            this.painelTabuleiro.Controls.Add(this.n12);
            this.painelTabuleiro.Controls.Add(this.n01);
            this.painelTabuleiro.Controls.Add(this.n11);
            this.painelTabuleiro.Controls.Add(this.n24);
            this.painelTabuleiro.Controls.Add(this.n34);
            this.painelTabuleiro.Controls.Add(this.n23);
            this.painelTabuleiro.Controls.Add(this.n33);
            this.painelTabuleiro.Controls.Add(this.n44);
            this.painelTabuleiro.Controls.Add(this.n22);
            this.painelTabuleiro.Controls.Add(this.n43);
            this.painelTabuleiro.Controls.Add(this.n32);
            this.painelTabuleiro.Controls.Add(this.n54);
            this.painelTabuleiro.Controls.Add(this.n21);
            this.painelTabuleiro.Controls.Add(this.n42);
            this.painelTabuleiro.Controls.Add(this.n31);
            this.painelTabuleiro.Controls.Add(this.n53);
            this.painelTabuleiro.Controls.Add(this.n41);
            this.painelTabuleiro.Controls.Add(this.n52);
            this.painelTabuleiro.Controls.Add(this.n51);
            this.painelTabuleiro.Controls.Add(this.n10);
            this.painelTabuleiro.Location = new System.Drawing.Point(13, 101);
            this.painelTabuleiro.Name = "painelTabuleiro";
            this.painelTabuleiro.Size = new System.Drawing.Size(454, 566);
            this.painelTabuleiro.TabIndex = 13;
            // 
            // btnSairPartida
            // 
            this.btnSairPartida.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSairPartida.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSairPartida.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSairPartida.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSairPartida.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnSairPartida.Location = new System.Drawing.Point(138, 511);
            this.btnSairPartida.Name = "btnSairPartida";
            this.btnSairPartida.Size = new System.Drawing.Size(49, 33);
            this.btnSairPartida.TabIndex = 46;
            this.btnSairPartida.Text = "Sair";
            this.btnSairPartida.UseVisualStyleBackColor = false;
            this.btnSairPartida.Click += new System.EventHandler(this.btnSairPartida_Click);
            // 
            // gbDesempregados
            // 
            this.gbDesempregados.Controls.Add(this.btnd12);
            this.gbDesempregados.Controls.Add(this.btnd11);
            this.gbDesempregados.Controls.Add(this.btnd10);
            this.gbDesempregados.Controls.Add(this.btnd9);
            this.gbDesempregados.Controls.Add(this.btnd8);
            this.gbDesempregados.Controls.Add(this.btnd7);
            this.gbDesempregados.Controls.Add(this.btnd6);
            this.gbDesempregados.Controls.Add(this.btnd5);
            this.gbDesempregados.Controls.Add(this.btnd4);
            this.gbDesempregados.Controls.Add(this.btnd3);
            this.gbDesempregados.Controls.Add(this.btnd2);
            this.gbDesempregados.Controls.Add(this.btnd1);
            this.gbDesempregados.Controls.Add(this.btnd0);
            this.gbDesempregados.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbDesempregados.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.gbDesempregados.Location = new System.Drawing.Point(413, 190);
            this.gbDesempregados.Name = "gbDesempregados";
            this.gbDesempregados.Size = new System.Drawing.Size(37, 367);
            this.gbDesempregados.TabIndex = 42;
            this.gbDesempregados.TabStop = false;
            // 
            // btnd12
            // 
            this.btnd12.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd12.Location = new System.Drawing.Point(6, 337);
            this.btnd12.Name = "btnd12";
            this.btnd12.Size = new System.Drawing.Size(25, 23);
            this.btnd12.TabIndex = 3;
            this.btnd12.TabStop = false;
            this.btnd12.Text = "P";
            this.btnd12.UseMnemonic = false;
            this.btnd12.UseVisualStyleBackColor = false;
            // 
            // btnd11
            // 
            this.btnd11.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd11.Location = new System.Drawing.Point(6, 310);
            this.btnd11.Name = "btnd11";
            this.btnd11.Size = new System.Drawing.Size(25, 23);
            this.btnd11.TabIndex = 3;
            this.btnd11.TabStop = false;
            this.btnd11.Text = "O";
            this.btnd11.UseMnemonic = false;
            this.btnd11.UseVisualStyleBackColor = false;
            // 
            // btnd10
            // 
            this.btnd10.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd10.Location = new System.Drawing.Point(6, 283);
            this.btnd10.Name = "btnd10";
            this.btnd10.Size = new System.Drawing.Size(25, 23);
            this.btnd10.TabIndex = 3;
            this.btnd10.TabStop = false;
            this.btnd10.Text = "N";
            this.btnd10.UseMnemonic = false;
            this.btnd10.UseVisualStyleBackColor = false;
            // 
            // btnd9
            // 
            this.btnd9.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd9.Location = new System.Drawing.Point(6, 256);
            this.btnd9.Name = "btnd9";
            this.btnd9.Size = new System.Drawing.Size(25, 23);
            this.btnd9.TabIndex = 3;
            this.btnd9.TabStop = false;
            this.btnd9.Text = "M";
            this.btnd9.UseMnemonic = false;
            this.btnd9.UseVisualStyleBackColor = false;
            // 
            // btnd8
            // 
            this.btnd8.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd8.Location = new System.Drawing.Point(6, 229);
            this.btnd8.Name = "btnd8";
            this.btnd8.Size = new System.Drawing.Size(25, 23);
            this.btnd8.TabIndex = 3;
            this.btnd8.TabStop = false;
            this.btnd8.Text = "L";
            this.btnd8.UseMnemonic = false;
            this.btnd8.UseVisualStyleBackColor = false;
            // 
            // btnd7
            // 
            this.btnd7.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd7.Location = new System.Drawing.Point(6, 202);
            this.btnd7.Name = "btnd7";
            this.btnd7.Size = new System.Drawing.Size(25, 23);
            this.btnd7.TabIndex = 3;
            this.btnd7.TabStop = false;
            this.btnd7.Text = "I";
            this.btnd7.UseMnemonic = false;
            this.btnd7.UseVisualStyleBackColor = false;
            // 
            // btnd6
            // 
            this.btnd6.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd6.Location = new System.Drawing.Point(6, 175);
            this.btnd6.Name = "btnd6";
            this.btnd6.Size = new System.Drawing.Size(25, 23);
            this.btnd6.TabIndex = 3;
            this.btnd6.TabStop = false;
            this.btnd6.Text = "G";
            this.btnd6.UseMnemonic = false;
            this.btnd6.UseVisualStyleBackColor = false;
            // 
            // btnd5
            // 
            this.btnd5.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd5.Location = new System.Drawing.Point(6, 148);
            this.btnd5.Name = "btnd5";
            this.btnd5.Size = new System.Drawing.Size(25, 23);
            this.btnd5.TabIndex = 3;
            this.btnd5.TabStop = false;
            this.btnd5.Text = "F";
            this.btnd5.UseMnemonic = false;
            this.btnd5.UseVisualStyleBackColor = false;
            // 
            // btnd4
            // 
            this.btnd4.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd4.Location = new System.Drawing.Point(6, 121);
            this.btnd4.Name = "btnd4";
            this.btnd4.Size = new System.Drawing.Size(25, 23);
            this.btnd4.TabIndex = 3;
            this.btnd4.TabStop = false;
            this.btnd4.Text = "E";
            this.btnd4.UseMnemonic = false;
            this.btnd4.UseVisualStyleBackColor = false;
            // 
            // btnd3
            // 
            this.btnd3.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd3.Location = new System.Drawing.Point(6, 94);
            this.btnd3.Name = "btnd3";
            this.btnd3.Size = new System.Drawing.Size(25, 23);
            this.btnd3.TabIndex = 3;
            this.btnd3.TabStop = false;
            this.btnd3.Text = "D";
            this.btnd3.UseMnemonic = false;
            this.btnd3.UseVisualStyleBackColor = false;
            // 
            // btnd2
            // 
            this.btnd2.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd2.Location = new System.Drawing.Point(6, 67);
            this.btnd2.Name = "btnd2";
            this.btnd2.Size = new System.Drawing.Size(25, 23);
            this.btnd2.TabIndex = 3;
            this.btnd2.TabStop = false;
            this.btnd2.Text = "C";
            this.btnd2.UseMnemonic = false;
            this.btnd2.UseVisualStyleBackColor = false;
            // 
            // btnd1
            // 
            this.btnd1.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd1.Location = new System.Drawing.Point(6, 40);
            this.btnd1.Name = "btnd1";
            this.btnd1.Size = new System.Drawing.Size(25, 23);
            this.btnd1.TabIndex = 3;
            this.btnd1.TabStop = false;
            this.btnd1.Text = "B";
            this.btnd1.UseMnemonic = false;
            this.btnd1.UseVisualStyleBackColor = false;
            // 
            // btnd0
            // 
            this.btnd0.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnd0.Location = new System.Drawing.Point(6, 13);
            this.btnd0.Name = "btnd0";
            this.btnd0.Size = new System.Drawing.Size(25, 23);
            this.btnd0.TabIndex = 3;
            this.btnd0.TabStop = false;
            this.btnd0.Text = "A";
            this.btnd0.UseMnemonic = false;
            this.btnd0.UseVisualStyleBackColor = false;
            // 
            // btnConfiguracoes
            // 
            this.btnConfiguracoes.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnConfiguracoes.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnConfiguracoes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfiguracoes.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfiguracoes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnConfiguracoes.Location = new System.Drawing.Point(3, 511);
            this.btnConfiguracoes.Name = "btnConfiguracoes";
            this.btnConfiguracoes.Size = new System.Drawing.Size(132, 33);
            this.btnConfiguracoes.TabIndex = 45;
            this.btnConfiguracoes.Text = "Configurações";
            this.btnConfiguracoes.UseVisualStyleBackColor = false;
            this.btnConfiguracoes.Click += new System.EventHandler(this.btnConfiguracoes_Click);
            // 
            // btnIniciarPartida
            // 
            this.btnIniciarPartida.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnIniciarPartida.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnIniciarPartida.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIniciarPartida.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIniciarPartida.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnIniciarPartida.Location = new System.Drawing.Point(3, 476);
            this.btnIniciarPartida.Name = "btnIniciarPartida";
            this.btnIniciarPartida.Size = new System.Drawing.Size(184, 33);
            this.btnIniciarPartida.TabIndex = 45;
            this.btnIniciarPartida.Text = "Iniciar Partida";
            this.btnIniciarPartida.UseVisualStyleBackColor = false;
            this.btnIniciarPartida.Click += new System.EventHandler(this.btnIniciarPartida_Click);
            // 
            // gbVotacao
            // 
            this.gbVotacao.Controls.Add(this.btnNao);
            this.gbVotacao.Controls.Add(this.labelPerguntaVotacao);
            this.gbVotacao.Controls.Add(this.btnSim);
            this.gbVotacao.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbVotacao.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.gbVotacao.Location = new System.Drawing.Point(3, 352);
            this.gbVotacao.Name = "gbVotacao";
            this.gbVotacao.Size = new System.Drawing.Size(181, 111);
            this.gbVotacao.TabIndex = 43;
            this.gbVotacao.TabStop = false;
            this.gbVotacao.Text = "Votação";
            // 
            // btnNao
            // 
            this.btnNao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnNao.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnNao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNao.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnNao.Location = new System.Drawing.Point(112, 80);
            this.btnNao.Name = "btnNao";
            this.btnNao.Size = new System.Drawing.Size(63, 25);
            this.btnNao.TabIndex = 7;
            this.btnNao.Text = "Não";
            this.btnNao.UseVisualStyleBackColor = false;
            this.btnNao.Click += new System.EventHandler(this.btnNao_Click);
            // 
            // labelPerguntaVotacao
            // 
            this.labelPerguntaVotacao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelPerguntaVotacao.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPerguntaVotacao.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.labelPerguntaVotacao.Location = new System.Drawing.Point(9, 18);
            this.labelPerguntaVotacao.Name = "labelPerguntaVotacao";
            this.labelPerguntaVotacao.Size = new System.Drawing.Size(163, 59);
            this.labelPerguntaVotacao.TabIndex = 18;
            this.labelPerguntaVotacao.Text = "Você escolhe o candidato Bolsonaro para ser Presidente?";
            // 
            // btnSim
            // 
            this.btnSim.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSim.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSim.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSim.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnSim.Location = new System.Drawing.Point(9, 80);
            this.btnSim.Name = "btnSim";
            this.btnSim.Size = new System.Drawing.Size(63, 25);
            this.btnSim.TabIndex = 7;
            this.btnSim.Text = "Sim";
            this.btnSim.UseVisualStyleBackColor = false;
            this.btnSim.Click += new System.EventHandler(this.btnSim_Click);
            // 
            // gbPosicionamento
            // 
            this.gbPosicionamento.Controls.Add(this.txtPersonagem);
            this.gbPosicionamento.Controls.Add(this.txtSetor);
            this.gbPosicionamento.Controls.Add(this.label7);
            this.gbPosicionamento.Controls.Add(this.btnPromover);
            this.gbPosicionamento.Controls.Add(this.btnPosicionar);
            this.gbPosicionamento.Controls.Add(this.label8);
            this.gbPosicionamento.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbPosicionamento.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.gbPosicionamento.Location = new System.Drawing.Point(3, 196);
            this.gbPosicionamento.Name = "gbPosicionamento";
            this.gbPosicionamento.Size = new System.Drawing.Size(181, 150);
            this.gbPosicionamento.TabIndex = 44;
            this.gbPosicionamento.TabStop = false;
            this.gbPosicionamento.Text = "Posicionamento";
            // 
            // txtPersonagem
            // 
            this.txtPersonagem.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPersonagem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.txtPersonagem.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtPersonagem.Location = new System.Drawing.Point(9, 84);
            this.txtPersonagem.MaxLength = 1;
            this.txtPersonagem.Name = "txtPersonagem";
            this.txtPersonagem.Size = new System.Drawing.Size(166, 22);
            this.txtPersonagem.TabIndex = 19;
            // 
            // txtSetor
            // 
            this.txtSetor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSetor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.txtSetor.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtSetor.Location = new System.Drawing.Point(9, 38);
            this.txtSetor.MaxLength = 1;
            this.txtSetor.Name = "txtSetor";
            this.txtSetor.Size = new System.Drawing.Size(166, 22);
            this.txtSetor.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label7.Location = new System.Drawing.Point(6, 64);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 17);
            this.label7.TabIndex = 18;
            this.label7.Text = "Personagem:";
            // 
            // btnPromover
            // 
            this.btnPromover.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPromover.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnPromover.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPromover.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPromover.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnPromover.Location = new System.Drawing.Point(97, 114);
            this.btnPromover.Name = "btnPromover";
            this.btnPromover.Size = new System.Drawing.Size(78, 25);
            this.btnPromover.TabIndex = 7;
            this.btnPromover.Text = "Promover";
            this.btnPromover.UseVisualStyleBackColor = false;
            this.btnPromover.Click += new System.EventHandler(this.btnPromover_Click);
            // 
            // btnPosicionar
            // 
            this.btnPosicionar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPosicionar.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnPosicionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPosicionar.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPosicionar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnPosicionar.Location = new System.Drawing.Point(9, 114);
            this.btnPosicionar.Name = "btnPosicionar";
            this.btnPosicionar.Size = new System.Drawing.Size(80, 25);
            this.btnPosicionar.TabIndex = 7;
            this.btnPosicionar.Text = "Posicionar";
            this.btnPosicionar.UseVisualStyleBackColor = false;
            this.btnPosicionar.Click += new System.EventHandler(this.btnPosicionar_Click);
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label8.Location = new System.Drawing.Point(6, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 17);
            this.label8.TabIndex = 18;
            this.label8.Text = "Setor:";
            // 
            // gbJogadores
            // 
            this.gbJogadores.Controls.Add(this.labelVotacao5);
            this.gbJogadores.Controls.Add(this.labelVotacao4);
            this.gbJogadores.Controls.Add(this.labelVotacao3);
            this.gbJogadores.Controls.Add(this.labelVotacao2);
            this.gbJogadores.Controls.Add(this.labelVotacao1);
            this.gbJogadores.Controls.Add(this.labelVotacao0);
            this.gbJogadores.Controls.Add(this.j1);
            this.gbJogadores.Controls.Add(this.j5);
            this.gbJogadores.Controls.Add(this.j4);
            this.gbJogadores.Controls.Add(this.j3);
            this.gbJogadores.Controls.Add(this.lblPontos5);
            this.gbJogadores.Controls.Add(this.lblPontos4);
            this.gbJogadores.Controls.Add(this.lblPontos3);
            this.gbJogadores.Controls.Add(this.lblPontos2);
            this.gbJogadores.Controls.Add(this.lblPontos1);
            this.gbJogadores.Controls.Add(this.lblJogadas5);
            this.gbJogadores.Controls.Add(this.lblJogadas4);
            this.gbJogadores.Controls.Add(this.lblJogadas3);
            this.gbJogadores.Controls.Add(this.lblJogadas2);
            this.gbJogadores.Controls.Add(this.lblJogadas1);
            this.gbJogadores.Controls.Add(this.lblJogadas0);
            this.gbJogadores.Controls.Add(this.lblPontos0);
            this.gbJogadores.Controls.Add(this.j2);
            this.gbJogadores.Controls.Add(this.nao53);
            this.gbJogadores.Controls.Add(this.nao52);
            this.gbJogadores.Controls.Add(this.nao51);
            this.gbJogadores.Controls.Add(this.nao50);
            this.gbJogadores.Controls.Add(this.nao43);
            this.gbJogadores.Controls.Add(this.nao42);
            this.gbJogadores.Controls.Add(this.nao41);
            this.gbJogadores.Controls.Add(this.nao40);
            this.gbJogadores.Controls.Add(this.nao33);
            this.gbJogadores.Controls.Add(this.nao32);
            this.gbJogadores.Controls.Add(this.nao31);
            this.gbJogadores.Controls.Add(this.nao30);
            this.gbJogadores.Controls.Add(this.nao23);
            this.gbJogadores.Controls.Add(this.nao22);
            this.gbJogadores.Controls.Add(this.nao21);
            this.gbJogadores.Controls.Add(this.nao20);
            this.gbJogadores.Controls.Add(this.nao13);
            this.gbJogadores.Controls.Add(this.nao12);
            this.gbJogadores.Controls.Add(this.nao11);
            this.gbJogadores.Controls.Add(this.nao10);
            this.gbJogadores.Controls.Add(this.nao03);
            this.gbJogadores.Controls.Add(this.nao02);
            this.gbJogadores.Controls.Add(this.nao01);
            this.gbJogadores.Controls.Add(this.nao00);
            this.gbJogadores.Controls.Add(this.j0);
            this.gbJogadores.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbJogadores.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.gbJogadores.Location = new System.Drawing.Point(3, 5);
            this.gbJogadores.Name = "gbJogadores";
            this.gbJogadores.Size = new System.Drawing.Size(447, 185);
            this.gbJogadores.TabIndex = 42;
            this.gbJogadores.TabStop = false;
            this.gbJogadores.Text = "Jogadores";
            // 
            // labelVotacao5
            // 
            this.labelVotacao5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelVotacao5.AutoSize = true;
            this.labelVotacao5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVotacao5.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.labelVotacao5.Location = new System.Drawing.Point(341, 156);
            this.labelVotacao5.Name = "labelVotacao5";
            this.labelVotacao5.Size = new System.Drawing.Size(42, 17);
            this.labelVotacao5.TabIndex = 19;
            this.labelVotacao5.Text = "votos";
            this.labelVotacao5.Click += new System.EventHandler(this.label5_Click);
            // 
            // labelVotacao4
            // 
            this.labelVotacao4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelVotacao4.AutoSize = true;
            this.labelVotacao4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVotacao4.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.labelVotacao4.Location = new System.Drawing.Point(341, 129);
            this.labelVotacao4.Name = "labelVotacao4";
            this.labelVotacao4.Size = new System.Drawing.Size(42, 17);
            this.labelVotacao4.TabIndex = 20;
            this.labelVotacao4.Text = "votos";
            // 
            // labelVotacao3
            // 
            this.labelVotacao3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelVotacao3.AutoSize = true;
            this.labelVotacao3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVotacao3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.labelVotacao3.Location = new System.Drawing.Point(341, 102);
            this.labelVotacao3.Name = "labelVotacao3";
            this.labelVotacao3.Size = new System.Drawing.Size(42, 17);
            this.labelVotacao3.TabIndex = 21;
            this.labelVotacao3.Text = "votos";
            // 
            // labelVotacao2
            // 
            this.labelVotacao2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelVotacao2.AutoSize = true;
            this.labelVotacao2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVotacao2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.labelVotacao2.Location = new System.Drawing.Point(341, 75);
            this.labelVotacao2.Name = "labelVotacao2";
            this.labelVotacao2.Size = new System.Drawing.Size(42, 17);
            this.labelVotacao2.TabIndex = 22;
            this.labelVotacao2.Text = "votos";
            // 
            // labelVotacao1
            // 
            this.labelVotacao1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelVotacao1.AutoSize = true;
            this.labelVotacao1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVotacao1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.labelVotacao1.Location = new System.Drawing.Point(341, 48);
            this.labelVotacao1.Name = "labelVotacao1";
            this.labelVotacao1.Size = new System.Drawing.Size(42, 17);
            this.labelVotacao1.TabIndex = 23;
            this.labelVotacao1.Text = "votos";
            // 
            // labelVotacao0
            // 
            this.labelVotacao0.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelVotacao0.AutoSize = true;
            this.labelVotacao0.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVotacao0.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.labelVotacao0.Location = new System.Drawing.Point(341, 21);
            this.labelVotacao0.Name = "labelVotacao0";
            this.labelVotacao0.Size = new System.Drawing.Size(42, 17);
            this.labelVotacao0.TabIndex = 24;
            this.labelVotacao0.Text = "votos";
            // 
            // j1
            // 
            this.j1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.j1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.j1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.j1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.j1.Location = new System.Drawing.Point(6, 48);
            this.j1.Name = "j1";
            this.j1.Size = new System.Drawing.Size(106, 25);
            this.j1.TabIndex = 8;
            this.j1.UseVisualStyleBackColor = false;
            this.j1.Visible = false;
            // 
            // j5
            // 
            this.j5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.j5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.j5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j5.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.j5.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.j5.Location = new System.Drawing.Point(6, 156);
            this.j5.Name = "j5";
            this.j5.Size = new System.Drawing.Size(106, 25);
            this.j5.TabIndex = 7;
            this.j5.UseVisualStyleBackColor = false;
            this.j5.Visible = false;
            // 
            // j4
            // 
            this.j4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.j4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.j4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j4.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.j4.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.j4.Location = new System.Drawing.Point(6, 129);
            this.j4.Name = "j4";
            this.j4.Size = new System.Drawing.Size(106, 25);
            this.j4.TabIndex = 7;
            this.j4.UseVisualStyleBackColor = false;
            this.j4.Visible = false;
            // 
            // j3
            // 
            this.j3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.j3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.j3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j3.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.j3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.j3.Location = new System.Drawing.Point(6, 102);
            this.j3.Name = "j3";
            this.j3.Size = new System.Drawing.Size(106, 25);
            this.j3.TabIndex = 7;
            this.j3.UseVisualStyleBackColor = false;
            this.j3.Visible = false;
            // 
            // lblPontos5
            // 
            this.lblPontos5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPontos5.AutoSize = true;
            this.lblPontos5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPontos5.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblPontos5.Location = new System.Drawing.Point(232, 160);
            this.lblPontos5.Name = "lblPontos5";
            this.lblPontos5.Size = new System.Drawing.Size(15, 17);
            this.lblPontos5.TabIndex = 18;
            this.lblPontos5.Text = "0";
            // 
            // lblPontos4
            // 
            this.lblPontos4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPontos4.AutoSize = true;
            this.lblPontos4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPontos4.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblPontos4.Location = new System.Drawing.Point(232, 133);
            this.lblPontos4.Name = "lblPontos4";
            this.lblPontos4.Size = new System.Drawing.Size(15, 17);
            this.lblPontos4.TabIndex = 18;
            this.lblPontos4.Text = "0";
            // 
            // lblPontos3
            // 
            this.lblPontos3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPontos3.AutoSize = true;
            this.lblPontos3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPontos3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblPontos3.Location = new System.Drawing.Point(232, 106);
            this.lblPontos3.Name = "lblPontos3";
            this.lblPontos3.Size = new System.Drawing.Size(15, 17);
            this.lblPontos3.TabIndex = 18;
            this.lblPontos3.Text = "0";
            // 
            // lblPontos2
            // 
            this.lblPontos2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPontos2.AutoSize = true;
            this.lblPontos2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPontos2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblPontos2.Location = new System.Drawing.Point(232, 79);
            this.lblPontos2.Name = "lblPontos2";
            this.lblPontos2.Size = new System.Drawing.Size(15, 17);
            this.lblPontos2.TabIndex = 18;
            this.lblPontos2.Text = "0";
            // 
            // lblPontos1
            // 
            this.lblPontos1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPontos1.AutoSize = true;
            this.lblPontos1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPontos1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblPontos1.Location = new System.Drawing.Point(232, 54);
            this.lblPontos1.Name = "lblPontos1";
            this.lblPontos1.Size = new System.Drawing.Size(15, 17);
            this.lblPontos1.TabIndex = 18;
            this.lblPontos1.Text = "0";
            // 
            // lblJogadas5
            // 
            this.lblJogadas5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblJogadas5.AutoSize = true;
            this.lblJogadas5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogadas5.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblJogadas5.Location = new System.Drawing.Point(263, 160);
            this.lblJogadas5.Name = "lblJogadas5";
            this.lblJogadas5.Size = new System.Drawing.Size(0, 17);
            this.lblJogadas5.TabIndex = 18;
            // 
            // lblJogadas4
            // 
            this.lblJogadas4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblJogadas4.AutoSize = true;
            this.lblJogadas4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogadas4.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblJogadas4.Location = new System.Drawing.Point(263, 133);
            this.lblJogadas4.Name = "lblJogadas4";
            this.lblJogadas4.Size = new System.Drawing.Size(0, 17);
            this.lblJogadas4.TabIndex = 18;
            // 
            // lblJogadas3
            // 
            this.lblJogadas3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblJogadas3.AutoSize = true;
            this.lblJogadas3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogadas3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblJogadas3.Location = new System.Drawing.Point(263, 106);
            this.lblJogadas3.Name = "lblJogadas3";
            this.lblJogadas3.Size = new System.Drawing.Size(0, 17);
            this.lblJogadas3.TabIndex = 18;
            // 
            // lblJogadas2
            // 
            this.lblJogadas2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblJogadas2.AutoSize = true;
            this.lblJogadas2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogadas2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblJogadas2.Location = new System.Drawing.Point(263, 79);
            this.lblJogadas2.Name = "lblJogadas2";
            this.lblJogadas2.Size = new System.Drawing.Size(0, 17);
            this.lblJogadas2.TabIndex = 18;
            // 
            // lblJogadas1
            // 
            this.lblJogadas1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblJogadas1.AutoSize = true;
            this.lblJogadas1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogadas1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblJogadas1.Location = new System.Drawing.Point(263, 52);
            this.lblJogadas1.Name = "lblJogadas1";
            this.lblJogadas1.Size = new System.Drawing.Size(0, 17);
            this.lblJogadas1.TabIndex = 18;
            // 
            // lblJogadas0
            // 
            this.lblJogadas0.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblJogadas0.AutoSize = true;
            this.lblJogadas0.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogadas0.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblJogadas0.Location = new System.Drawing.Point(263, 25);
            this.lblJogadas0.Name = "lblJogadas0";
            this.lblJogadas0.Size = new System.Drawing.Size(0, 17);
            this.lblJogadas0.TabIndex = 18;
            // 
            // lblPontos0
            // 
            this.lblPontos0.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPontos0.AutoSize = true;
            this.lblPontos0.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPontos0.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblPontos0.Location = new System.Drawing.Point(232, 25);
            this.lblPontos0.Name = "lblPontos0";
            this.lblPontos0.Size = new System.Drawing.Size(15, 17);
            this.lblPontos0.TabIndex = 18;
            this.lblPontos0.Text = "0";
            // 
            // j2
            // 
            this.j2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.j2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.j2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.j2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.j2.Location = new System.Drawing.Point(6, 75);
            this.j2.Name = "j2";
            this.j2.Size = new System.Drawing.Size(106, 25);
            this.j2.TabIndex = 7;
            this.j2.UseVisualStyleBackColor = false;
            this.j2.Visible = false;
            // 
            // nao53
            // 
            this.nao53.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao53.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao53.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao53.Location = new System.Drawing.Point(196, 156);
            this.nao53.Name = "nao53";
            this.nao53.Size = new System.Drawing.Size(20, 25);
            this.nao53.TabIndex = 7;
            this.nao53.Text = "N";
            this.nao53.UseVisualStyleBackColor = false;
            this.nao53.Visible = false;
            // 
            // nao52
            // 
            this.nao52.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao52.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao52.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao52.Location = new System.Drawing.Point(170, 156);
            this.nao52.Name = "nao52";
            this.nao52.Size = new System.Drawing.Size(20, 25);
            this.nao52.TabIndex = 7;
            this.nao52.Text = "N";
            this.nao52.UseVisualStyleBackColor = false;
            this.nao52.Visible = false;
            // 
            // nao51
            // 
            this.nao51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao51.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao51.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao51.Location = new System.Drawing.Point(144, 156);
            this.nao51.Name = "nao51";
            this.nao51.Size = new System.Drawing.Size(20, 25);
            this.nao51.TabIndex = 7;
            this.nao51.Text = "N";
            this.nao51.UseVisualStyleBackColor = false;
            this.nao51.Visible = false;
            // 
            // nao50
            // 
            this.nao50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao50.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao50.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao50.Location = new System.Drawing.Point(118, 156);
            this.nao50.Name = "nao50";
            this.nao50.Size = new System.Drawing.Size(20, 25);
            this.nao50.TabIndex = 7;
            this.nao50.Text = "N";
            this.nao50.UseVisualStyleBackColor = false;
            this.nao50.Visible = false;
            // 
            // nao43
            // 
            this.nao43.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao43.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao43.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao43.Location = new System.Drawing.Point(196, 129);
            this.nao43.Name = "nao43";
            this.nao43.Size = new System.Drawing.Size(20, 25);
            this.nao43.TabIndex = 7;
            this.nao43.Text = "N";
            this.nao43.UseVisualStyleBackColor = false;
            this.nao43.Visible = false;
            // 
            // nao42
            // 
            this.nao42.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao42.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao42.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao42.Location = new System.Drawing.Point(170, 129);
            this.nao42.Name = "nao42";
            this.nao42.Size = new System.Drawing.Size(20, 25);
            this.nao42.TabIndex = 7;
            this.nao42.Text = "N";
            this.nao42.UseVisualStyleBackColor = false;
            this.nao42.Visible = false;
            // 
            // nao41
            // 
            this.nao41.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao41.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao41.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao41.Location = new System.Drawing.Point(144, 129);
            this.nao41.Name = "nao41";
            this.nao41.Size = new System.Drawing.Size(20, 25);
            this.nao41.TabIndex = 7;
            this.nao41.Text = "N";
            this.nao41.UseVisualStyleBackColor = false;
            this.nao41.Visible = false;
            // 
            // nao40
            // 
            this.nao40.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao40.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao40.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao40.Location = new System.Drawing.Point(118, 129);
            this.nao40.Name = "nao40";
            this.nao40.Size = new System.Drawing.Size(20, 25);
            this.nao40.TabIndex = 7;
            this.nao40.Text = "N";
            this.nao40.UseVisualStyleBackColor = false;
            this.nao40.Visible = false;
            // 
            // nao33
            // 
            this.nao33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao33.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao33.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao33.Location = new System.Drawing.Point(196, 102);
            this.nao33.Name = "nao33";
            this.nao33.Size = new System.Drawing.Size(20, 25);
            this.nao33.TabIndex = 7;
            this.nao33.Text = "N";
            this.nao33.UseVisualStyleBackColor = false;
            this.nao33.Visible = false;
            // 
            // nao32
            // 
            this.nao32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao32.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao32.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao32.Location = new System.Drawing.Point(170, 102);
            this.nao32.Name = "nao32";
            this.nao32.Size = new System.Drawing.Size(20, 25);
            this.nao32.TabIndex = 7;
            this.nao32.Text = "N";
            this.nao32.UseVisualStyleBackColor = false;
            this.nao32.Visible = false;
            // 
            // nao31
            // 
            this.nao31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao31.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao31.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao31.Location = new System.Drawing.Point(144, 102);
            this.nao31.Name = "nao31";
            this.nao31.Size = new System.Drawing.Size(20, 25);
            this.nao31.TabIndex = 7;
            this.nao31.Text = "N";
            this.nao31.UseVisualStyleBackColor = false;
            this.nao31.Visible = false;
            // 
            // nao30
            // 
            this.nao30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao30.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao30.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao30.Location = new System.Drawing.Point(118, 102);
            this.nao30.Name = "nao30";
            this.nao30.Size = new System.Drawing.Size(20, 25);
            this.nao30.TabIndex = 7;
            this.nao30.Text = "N";
            this.nao30.UseVisualStyleBackColor = false;
            this.nao30.Visible = false;
            // 
            // nao23
            // 
            this.nao23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao23.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao23.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao23.Location = new System.Drawing.Point(196, 75);
            this.nao23.Name = "nao23";
            this.nao23.Size = new System.Drawing.Size(20, 25);
            this.nao23.TabIndex = 7;
            this.nao23.Text = "N";
            this.nao23.UseVisualStyleBackColor = false;
            this.nao23.Visible = false;
            // 
            // nao22
            // 
            this.nao22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao22.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao22.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao22.Location = new System.Drawing.Point(170, 75);
            this.nao22.Name = "nao22";
            this.nao22.Size = new System.Drawing.Size(20, 25);
            this.nao22.TabIndex = 7;
            this.nao22.Text = "N";
            this.nao22.UseVisualStyleBackColor = false;
            this.nao22.Visible = false;
            // 
            // nao21
            // 
            this.nao21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao21.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao21.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao21.Location = new System.Drawing.Point(144, 75);
            this.nao21.Name = "nao21";
            this.nao21.Size = new System.Drawing.Size(20, 25);
            this.nao21.TabIndex = 7;
            this.nao21.Text = "N";
            this.nao21.UseVisualStyleBackColor = false;
            this.nao21.Visible = false;
            // 
            // nao20
            // 
            this.nao20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao20.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao20.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao20.Location = new System.Drawing.Point(118, 75);
            this.nao20.Name = "nao20";
            this.nao20.Size = new System.Drawing.Size(20, 25);
            this.nao20.TabIndex = 7;
            this.nao20.Text = "N";
            this.nao20.UseVisualStyleBackColor = false;
            this.nao20.Visible = false;
            // 
            // nao13
            // 
            this.nao13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao13.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao13.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao13.Location = new System.Drawing.Point(196, 48);
            this.nao13.Name = "nao13";
            this.nao13.Size = new System.Drawing.Size(20, 25);
            this.nao13.TabIndex = 7;
            this.nao13.Text = "N";
            this.nao13.UseVisualStyleBackColor = false;
            this.nao13.Visible = false;
            // 
            // nao12
            // 
            this.nao12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao12.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao12.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao12.Location = new System.Drawing.Point(170, 48);
            this.nao12.Name = "nao12";
            this.nao12.Size = new System.Drawing.Size(20, 25);
            this.nao12.TabIndex = 7;
            this.nao12.Text = "N";
            this.nao12.UseVisualStyleBackColor = false;
            this.nao12.Visible = false;
            // 
            // nao11
            // 
            this.nao11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao11.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao11.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao11.Location = new System.Drawing.Point(144, 48);
            this.nao11.Name = "nao11";
            this.nao11.Size = new System.Drawing.Size(20, 25);
            this.nao11.TabIndex = 7;
            this.nao11.Text = "N";
            this.nao11.UseVisualStyleBackColor = false;
            this.nao11.Visible = false;
            // 
            // nao10
            // 
            this.nao10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao10.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao10.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao10.Location = new System.Drawing.Point(118, 48);
            this.nao10.Name = "nao10";
            this.nao10.Size = new System.Drawing.Size(20, 25);
            this.nao10.TabIndex = 7;
            this.nao10.Text = "N";
            this.nao10.UseVisualStyleBackColor = false;
            this.nao10.Visible = false;
            // 
            // nao03
            // 
            this.nao03.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao03.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao03.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao03.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao03.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao03.Location = new System.Drawing.Point(196, 21);
            this.nao03.Name = "nao03";
            this.nao03.Size = new System.Drawing.Size(20, 25);
            this.nao03.TabIndex = 7;
            this.nao03.Text = "N";
            this.nao03.UseVisualStyleBackColor = false;
            this.nao03.Visible = false;
            // 
            // nao02
            // 
            this.nao02.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao02.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao02.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao02.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao02.Location = new System.Drawing.Point(170, 21);
            this.nao02.Name = "nao02";
            this.nao02.Size = new System.Drawing.Size(20, 25);
            this.nao02.TabIndex = 7;
            this.nao02.Text = "N";
            this.nao02.UseVisualStyleBackColor = false;
            this.nao02.Visible = false;
            // 
            // nao01
            // 
            this.nao01.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao01.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao01.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao01.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao01.Location = new System.Drawing.Point(144, 21);
            this.nao01.Name = "nao01";
            this.nao01.Size = new System.Drawing.Size(20, 25);
            this.nao01.TabIndex = 7;
            this.nao01.Text = "N";
            this.nao01.UseVisualStyleBackColor = false;
            this.nao01.Visible = false;
            // 
            // nao00
            // 
            this.nao00.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nao00.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.nao00.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nao00.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nao00.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.nao00.Location = new System.Drawing.Point(118, 21);
            this.nao00.Name = "nao00";
            this.nao00.Size = new System.Drawing.Size(20, 25);
            this.nao00.TabIndex = 7;
            this.nao00.Text = "N";
            this.nao00.UseVisualStyleBackColor = false;
            this.nao00.Visible = false;
            // 
            // j0
            // 
            this.j0.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.j0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.j0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.j0.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.j0.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.j0.Location = new System.Drawing.Point(6, 21);
            this.j0.Name = "j0";
            this.j0.Size = new System.Drawing.Size(106, 25);
            this.j0.TabIndex = 7;
            this.j0.UseVisualStyleBackColor = false;
            this.j0.Visible = false;
            // 
            // lblNumRodada
            // 
            this.lblNumRodada.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNumRodada.AutoSize = true;
            this.lblNumRodada.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumRodada.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblNumRodada.Location = new System.Drawing.Point(345, 539);
            this.lblNumRodada.Name = "lblNumRodada";
            this.lblNumRodada.Size = new System.Drawing.Size(28, 17);
            this.lblNumRodada.TabIndex = 37;
            this.lblNumRodada.Text = "0/3";
            // 
            // lblPontuacaoTotal
            // 
            this.lblPontuacaoTotal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPontuacaoTotal.AutoSize = true;
            this.lblPontuacaoTotal.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPontuacaoTotal.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblPontuacaoTotal.Location = new System.Drawing.Point(345, 502);
            this.lblPontuacaoTotal.Name = "lblPontuacaoTotal";
            this.lblPontuacaoTotal.Size = new System.Drawing.Size(15, 17);
            this.lblPontuacaoTotal.TabIndex = 38;
            this.lblPontuacaoTotal.Text = "0";
            // 
            // lblPontuacaoAtual
            // 
            this.lblPontuacaoAtual.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPontuacaoAtual.AutoSize = true;
            this.lblPontuacaoAtual.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPontuacaoAtual.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblPontuacaoAtual.Location = new System.Drawing.Point(345, 521);
            this.lblPontuacaoAtual.Name = "lblPontuacaoAtual";
            this.lblPontuacaoAtual.Size = new System.Drawing.Size(15, 17);
            this.lblPontuacaoAtual.TabIndex = 38;
            this.lblPontuacaoAtual.Text = "0";
            // 
            // lblRodada
            // 
            this.lblRodada.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRodada.AutoSize = true;
            this.lblRodada.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRodada.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblRodada.Location = new System.Drawing.Point(275, 539);
            this.lblRodada.Name = "lblRodada";
            this.lblRodada.Size = new System.Drawing.Size(64, 16);
            this.lblRodada.TabIndex = 39;
            this.lblRodada.Text = "Rodada:";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label2.Location = new System.Drawing.Point(223, 502);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 16);
            this.label2.TabIndex = 40;
            this.label2.Text = "Pontuação Total:";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label3.Location = new System.Drawing.Point(219, 521);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 16);
            this.label3.TabIndex = 40;
            this.label3.Text = "Pontuação Atual:";
            // 
            // n04
            // 
            this.n04.Cursor = System.Windows.Forms.Cursors.Default;
            this.n04.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n04.Location = new System.Drawing.Point(346, 454);
            this.n04.Name = "n04";
            this.n04.Size = new System.Drawing.Size(40, 37);
            this.n04.TabIndex = 35;
            this.n04.TabStop = false;
            this.n04.UseMnemonic = false;
            this.n04.UseVisualStyleBackColor = false;
            // 
            // n14
            // 
            this.n14.Cursor = System.Windows.Forms.Cursors.Default;
            this.n14.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n14.Location = new System.Drawing.Point(346, 411);
            this.n14.Name = "n14";
            this.n14.Size = new System.Drawing.Size(40, 37);
            this.n14.TabIndex = 36;
            this.n14.TabStop = false;
            this.n14.UseMnemonic = false;
            this.n14.UseVisualStyleBackColor = false;
            // 
            // n03
            // 
            this.n03.Cursor = System.Windows.Forms.Cursors.Default;
            this.n03.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n03.Location = new System.Drawing.Point(300, 454);
            this.n03.Name = "n03";
            this.n03.Size = new System.Drawing.Size(40, 37);
            this.n03.TabIndex = 33;
            this.n03.TabStop = false;
            this.n03.UseMnemonic = false;
            this.n03.UseVisualStyleBackColor = false;
            // 
            // n13
            // 
            this.n13.Cursor = System.Windows.Forms.Cursors.Default;
            this.n13.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n13.Location = new System.Drawing.Point(300, 411);
            this.n13.Name = "n13";
            this.n13.Size = new System.Drawing.Size(40, 37);
            this.n13.TabIndex = 34;
            this.n13.TabStop = false;
            this.n13.UseMnemonic = false;
            this.n13.UseVisualStyleBackColor = false;
            // 
            // n02
            // 
            this.n02.Cursor = System.Windows.Forms.Cursors.Default;
            this.n02.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n02.Location = new System.Drawing.Point(254, 454);
            this.n02.Name = "n02";
            this.n02.Size = new System.Drawing.Size(40, 37);
            this.n02.TabIndex = 31;
            this.n02.TabStop = false;
            this.n02.UseMnemonic = false;
            this.n02.UseVisualStyleBackColor = false;
            // 
            // n12
            // 
            this.n12.Cursor = System.Windows.Forms.Cursors.Default;
            this.n12.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n12.Location = new System.Drawing.Point(254, 411);
            this.n12.Name = "n12";
            this.n12.Size = new System.Drawing.Size(40, 37);
            this.n12.TabIndex = 32;
            this.n12.TabStop = false;
            this.n12.UseMnemonic = false;
            this.n12.UseVisualStyleBackColor = false;
            // 
            // n01
            // 
            this.n01.Cursor = System.Windows.Forms.Cursors.Default;
            this.n01.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n01.Location = new System.Drawing.Point(208, 454);
            this.n01.Name = "n01";
            this.n01.Size = new System.Drawing.Size(40, 37);
            this.n01.TabIndex = 29;
            this.n01.TabStop = false;
            this.n01.UseMnemonic = false;
            this.n01.UseVisualStyleBackColor = false;
            // 
            // n11
            // 
            this.n11.Cursor = System.Windows.Forms.Cursors.Default;
            this.n11.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n11.Location = new System.Drawing.Point(208, 411);
            this.n11.Name = "n11";
            this.n11.Size = new System.Drawing.Size(40, 37);
            this.n11.TabIndex = 30;
            this.n11.TabStop = false;
            this.n11.UseMnemonic = false;
            this.n11.UseVisualStyleBackColor = false;
            // 
            // n24
            // 
            this.n24.Cursor = System.Windows.Forms.Cursors.Default;
            this.n24.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n24.Location = new System.Drawing.Point(346, 368);
            this.n24.Name = "n24";
            this.n24.Size = new System.Drawing.Size(40, 37);
            this.n24.TabIndex = 25;
            this.n24.TabStop = false;
            this.n24.UseMnemonic = false;
            this.n24.UseVisualStyleBackColor = false;
            // 
            // n34
            // 
            this.n34.Cursor = System.Windows.Forms.Cursors.Default;
            this.n34.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n34.Location = new System.Drawing.Point(346, 325);
            this.n34.Name = "n34";
            this.n34.Size = new System.Drawing.Size(40, 37);
            this.n34.TabIndex = 26;
            this.n34.TabStop = false;
            this.n34.UseMnemonic = false;
            this.n34.UseVisualStyleBackColor = false;
            // 
            // n23
            // 
            this.n23.Cursor = System.Windows.Forms.Cursors.Default;
            this.n23.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n23.Location = new System.Drawing.Point(300, 368);
            this.n23.Name = "n23";
            this.n23.Size = new System.Drawing.Size(40, 37);
            this.n23.TabIndex = 21;
            this.n23.TabStop = false;
            this.n23.UseMnemonic = false;
            this.n23.UseVisualStyleBackColor = false;
            // 
            // n33
            // 
            this.n33.Cursor = System.Windows.Forms.Cursors.Default;
            this.n33.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n33.Location = new System.Drawing.Point(300, 325);
            this.n33.Name = "n33";
            this.n33.Size = new System.Drawing.Size(40, 37);
            this.n33.TabIndex = 22;
            this.n33.TabStop = false;
            this.n33.UseMnemonic = false;
            this.n33.UseVisualStyleBackColor = false;
            // 
            // n44
            // 
            this.n44.Cursor = System.Windows.Forms.Cursors.Default;
            this.n44.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n44.Location = new System.Drawing.Point(346, 282);
            this.n44.Name = "n44";
            this.n44.Size = new System.Drawing.Size(40, 37);
            this.n44.TabIndex = 27;
            this.n44.TabStop = false;
            this.n44.UseMnemonic = false;
            this.n44.UseVisualStyleBackColor = false;
            // 
            // n22
            // 
            this.n22.Cursor = System.Windows.Forms.Cursors.Default;
            this.n22.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n22.Location = new System.Drawing.Point(254, 368);
            this.n22.Name = "n22";
            this.n22.Size = new System.Drawing.Size(40, 37);
            this.n22.TabIndex = 17;
            this.n22.TabStop = false;
            this.n22.UseMnemonic = false;
            this.n22.UseVisualStyleBackColor = false;
            // 
            // n43
            // 
            this.n43.Cursor = System.Windows.Forms.Cursors.Default;
            this.n43.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n43.Location = new System.Drawing.Point(300, 282);
            this.n43.Name = "n43";
            this.n43.Size = new System.Drawing.Size(40, 37);
            this.n43.TabIndex = 23;
            this.n43.TabStop = false;
            this.n43.UseMnemonic = false;
            this.n43.UseVisualStyleBackColor = false;
            // 
            // n32
            // 
            this.n32.Cursor = System.Windows.Forms.Cursors.Default;
            this.n32.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n32.Location = new System.Drawing.Point(254, 325);
            this.n32.Name = "n32";
            this.n32.Size = new System.Drawing.Size(40, 37);
            this.n32.TabIndex = 18;
            this.n32.TabStop = false;
            this.n32.UseMnemonic = false;
            this.n32.UseVisualStyleBackColor = false;
            // 
            // n54
            // 
            this.n54.Cursor = System.Windows.Forms.Cursors.Default;
            this.n54.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n54.Location = new System.Drawing.Point(346, 239);
            this.n54.Name = "n54";
            this.n54.Size = new System.Drawing.Size(40, 37);
            this.n54.TabIndex = 28;
            this.n54.TabStop = false;
            this.n54.UseMnemonic = false;
            this.n54.UseVisualStyleBackColor = false;
            // 
            // n21
            // 
            this.n21.Cursor = System.Windows.Forms.Cursors.Default;
            this.n21.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n21.Location = new System.Drawing.Point(208, 368);
            this.n21.Name = "n21";
            this.n21.Size = new System.Drawing.Size(40, 37);
            this.n21.TabIndex = 13;
            this.n21.TabStop = false;
            this.n21.UseMnemonic = false;
            this.n21.UseVisualStyleBackColor = false;
            // 
            // n42
            // 
            this.n42.Cursor = System.Windows.Forms.Cursors.Default;
            this.n42.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n42.Location = new System.Drawing.Point(254, 282);
            this.n42.Name = "n42";
            this.n42.Size = new System.Drawing.Size(40, 37);
            this.n42.TabIndex = 19;
            this.n42.TabStop = false;
            this.n42.UseMnemonic = false;
            this.n42.UseVisualStyleBackColor = false;
            // 
            // n31
            // 
            this.n31.Cursor = System.Windows.Forms.Cursors.Default;
            this.n31.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n31.Location = new System.Drawing.Point(208, 325);
            this.n31.Name = "n31";
            this.n31.Size = new System.Drawing.Size(40, 37);
            this.n31.TabIndex = 14;
            this.n31.TabStop = false;
            this.n31.UseMnemonic = false;
            this.n31.UseVisualStyleBackColor = false;
            // 
            // n53
            // 
            this.n53.Cursor = System.Windows.Forms.Cursors.Default;
            this.n53.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n53.Location = new System.Drawing.Point(300, 239);
            this.n53.Name = "n53";
            this.n53.Size = new System.Drawing.Size(40, 37);
            this.n53.TabIndex = 24;
            this.n53.TabStop = false;
            this.n53.UseMnemonic = false;
            this.n53.UseVisualStyleBackColor = false;
            // 
            // n41
            // 
            this.n41.Cursor = System.Windows.Forms.Cursors.Default;
            this.n41.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n41.Location = new System.Drawing.Point(208, 282);
            this.n41.Name = "n41";
            this.n41.Size = new System.Drawing.Size(40, 37);
            this.n41.TabIndex = 15;
            this.n41.TabStop = false;
            this.n41.UseMnemonic = false;
            this.n41.UseVisualStyleBackColor = false;
            // 
            // n52
            // 
            this.n52.Cursor = System.Windows.Forms.Cursors.Default;
            this.n52.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n52.Location = new System.Drawing.Point(254, 239);
            this.n52.Name = "n52";
            this.n52.Size = new System.Drawing.Size(40, 37);
            this.n52.TabIndex = 20;
            this.n52.TabStop = false;
            this.n52.UseMnemonic = false;
            this.n52.UseVisualStyleBackColor = false;
            // 
            // n51
            // 
            this.n51.Cursor = System.Windows.Forms.Cursors.Default;
            this.n51.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n51.Location = new System.Drawing.Point(208, 239);
            this.n51.Name = "n51";
            this.n51.Size = new System.Drawing.Size(40, 37);
            this.n51.TabIndex = 16;
            this.n51.TabStop = false;
            this.n51.UseMnemonic = false;
            this.n51.UseVisualStyleBackColor = false;
            // 
            // n10
            // 
            this.n10.Cursor = System.Windows.Forms.Cursors.Default;
            this.n10.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.n10.Location = new System.Drawing.Point(276, 196);
            this.n10.Name = "n10";
            this.n10.Size = new System.Drawing.Size(40, 37);
            this.n10.TabIndex = 3;
            this.n10.TabStop = false;
            this.n10.UseMnemonic = false;
            this.n10.UseVisualStyleBackColor = false;
            // 
            // btnAutoJogo
            // 
            this.btnAutoJogo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAutoJogo.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAutoJogo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAutoJogo.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAutoJogo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnAutoJogo.Location = new System.Drawing.Point(5, 21);
            this.btnAutoJogo.Name = "btnAutoJogo";
            this.btnAutoJogo.Size = new System.Drawing.Size(191, 24);
            this.btnAutoJogo.TabIndex = 45;
            this.btnAutoJogo.Text = "Ativar Jogadas Automáticas";
            this.btnAutoJogo.UseVisualStyleBackColor = false;
            this.btnAutoJogo.Click += new System.EventHandler(this.btnAutoJogo_Click);
            // 
            // btnAlg5
            // 
            this.btnAlg5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAlg5.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAlg5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlg5.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlg5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnAlg5.Location = new System.Drawing.Point(44, 111);
            this.btnAlg5.Name = "btnAlg5";
            this.btnAlg5.Size = new System.Drawing.Size(30, 23);
            this.btnAlg5.TabIndex = 19;
            this.btnAlg5.Text = "a5";
            this.btnAlg5.UseVisualStyleBackColor = false;
            this.btnAlg5.Click += new System.EventHandler(this.btnAlg5_Click);
            // 
            // btnAlg7
            // 
            this.btnAlg7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAlg7.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAlg7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlg7.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlg7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnAlg7.Location = new System.Drawing.Point(80, 82);
            this.btnAlg7.Name = "btnAlg7";
            this.btnAlg7.Size = new System.Drawing.Size(30, 23);
            this.btnAlg7.TabIndex = 19;
            this.btnAlg7.Text = "a7";
            this.btnAlg7.UseVisualStyleBackColor = false;
            this.btnAlg7.Click += new System.EventHandler(this.btnAlg7_Click);
            // 
            // btnAlg4
            // 
            this.btnAlg4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAlg4.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAlg4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlg4.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlg4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnAlg4.Location = new System.Drawing.Point(44, 82);
            this.btnAlg4.Name = "btnAlg4";
            this.btnAlg4.Size = new System.Drawing.Size(30, 23);
            this.btnAlg4.TabIndex = 19;
            this.btnAlg4.Text = "a4";
            this.btnAlg4.UseVisualStyleBackColor = false;
            this.btnAlg4.Click += new System.EventHandler(this.btnAlg4_Click);
            // 
            // btnAlg3
            // 
            this.btnAlg3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAlg3.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAlg3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlg3.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlg3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnAlg3.Location = new System.Drawing.Point(42, 51);
            this.btnAlg3.Name = "btnAlg3";
            this.btnAlg3.Size = new System.Drawing.Size(30, 23);
            this.btnAlg3.TabIndex = 19;
            this.btnAlg3.Text = "a3";
            this.btnAlg3.UseVisualStyleBackColor = false;
            this.btnAlg3.Click += new System.EventHandler(this.btnAlg3_Click);
            // 
            // btnAlg2
            // 
            this.btnAlg2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAlg2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAlg2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlg2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlg2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnAlg2.Location = new System.Drawing.Point(8, 111);
            this.btnAlg2.Name = "btnAlg2";
            this.btnAlg2.Size = new System.Drawing.Size(30, 23);
            this.btnAlg2.TabIndex = 19;
            this.btnAlg2.Text = "a2";
            this.btnAlg2.UseVisualStyleBackColor = false;
            this.btnAlg2.Click += new System.EventHandler(this.btnAlg2_Click);
            // 
            // btnAlg1
            // 
            this.btnAlg1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAlg1.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAlg1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlg1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlg1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnAlg1.Location = new System.Drawing.Point(8, 82);
            this.btnAlg1.Name = "btnAlg1";
            this.btnAlg1.Size = new System.Drawing.Size(30, 23);
            this.btnAlg1.TabIndex = 19;
            this.btnAlg1.Text = "a1";
            this.btnAlg1.UseVisualStyleBackColor = false;
            this.btnAlg1.Click += new System.EventHandler(this.btnAlg1_Click);
            // 
            // btnAlg0
            // 
            this.btnAlg0.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAlg0.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAlg0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlg0.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlg0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnAlg0.Location = new System.Drawing.Point(6, 51);
            this.btnAlg0.Name = "btnAlg0";
            this.btnAlg0.Size = new System.Drawing.Size(30, 23);
            this.btnAlg0.TabIndex = 19;
            this.btnAlg0.Text = "a0";
            this.btnAlg0.UseVisualStyleBackColor = false;
            this.btnAlg0.Click += new System.EventHandler(this.btnAlg0_Click);
            // 
            // lblArquivoDebug
            // 
            this.lblArquivoDebug.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblArquivoDebug.AutoSize = true;
            this.lblArquivoDebug.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArquivoDebug.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblArquivoDebug.Location = new System.Drawing.Point(10, 681);
            this.lblArquivoDebug.Name = "lblArquivoDebug";
            this.lblArquivoDebug.Size = new System.Drawing.Size(96, 16);
            this.lblArquivoDebug.TabIndex = 14;
            this.lblArquivoDebug.Text = "Arquivo Debug: ";
            // 
            // lblErro
            // 
            this.lblErro.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblErro.AutoSize = true;
            this.lblErro.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErro.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblErro.Location = new System.Drawing.Point(9, 664);
            this.lblErro.Name = "lblErro";
            this.lblErro.Size = new System.Drawing.Size(59, 16);
            this.lblErro.TabIndex = 14;
            this.lblErro.Text = "Sucesso...";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // gbConfiguracoes
            // 
            this.gbConfiguracoes.Controls.Add(this.btnSomenteAtualizarTabuleiro);
            this.gbConfiguracoes.Controls.Add(this.numericUpDown1);
            this.gbConfiguracoes.Controls.Add(this.btnEntrarPartidaEmergencia);
            this.gbConfiguracoes.Controls.Add(this.txtSenhaPartidaEmergencia);
            this.gbConfiguracoes.Controls.Add(this.txtIdPartidaEmergencia);
            this.gbConfiguracoes.Controls.Add(this.lblSenhaPartidaEmergencia);
            this.gbConfiguracoes.Controls.Add(this.lblIdPartidaEmergencia);
            this.gbConfiguracoes.Controls.Add(this.lblSenhaJogadorEmergencia);
            this.gbConfiguracoes.Controls.Add(this.lblTempoSicronizacao);
            this.gbConfiguracoes.Controls.Add(this.lblIdJogadorEmergencia);
            this.gbConfiguracoes.Controls.Add(this.txtSenhaJogadorEmergencia);
            this.gbConfiguracoes.Controls.Add(this.txtIdJogadorEmergencia);
            this.gbConfiguracoes.Controls.Add(this.btnHabilitarDebug);
            this.gbConfiguracoes.Controls.Add(this.btnAlg13);
            this.gbConfiguracoes.Controls.Add(this.btnAlg10);
            this.gbConfiguracoes.Controls.Add(this.btnAutoJogo);
            this.gbConfiguracoes.Controls.Add(this.btnTimer);
            this.gbConfiguracoes.Controls.Add(this.btnHabilitarTimer);
            this.gbConfiguracoes.Controls.Add(this.btnAlg5);
            this.gbConfiguracoes.Controls.Add(this.btnAlg7);
            this.gbConfiguracoes.Controls.Add(this.btnAlg0);
            this.gbConfiguracoes.Controls.Add(this.btnAlg4);
            this.gbConfiguracoes.Controls.Add(this.btnAlg1);
            this.gbConfiguracoes.Controls.Add(this.btnAlg3);
            this.gbConfiguracoes.Controls.Add(this.btnAlg2);
            this.gbConfiguracoes.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbConfiguracoes.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.gbConfiguracoes.Location = new System.Drawing.Point(507, 104);
            this.gbConfiguracoes.Name = "gbConfiguracoes";
            this.gbConfiguracoes.Size = new System.Drawing.Size(361, 250);
            this.gbConfiguracoes.TabIndex = 42;
            this.gbConfiguracoes.TabStop = false;
            this.gbConfiguracoes.Text = "Configurações";
            // 
            // btnSomenteAtualizarTabuleiro
            // 
            this.btnSomenteAtualizarTabuleiro.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSomenteAtualizarTabuleiro.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSomenteAtualizarTabuleiro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSomenteAtualizarTabuleiro.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSomenteAtualizarTabuleiro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnSomenteAtualizarTabuleiro.Location = new System.Drawing.Point(113, 176);
            this.btnSomenteAtualizarTabuleiro.Name = "btnSomenteAtualizarTabuleiro";
            this.btnSomenteAtualizarTabuleiro.Size = new System.Drawing.Size(83, 40);
            this.btnSomenteAtualizarTabuleiro.TabIndex = 55;
            this.btnSomenteAtualizarTabuleiro.Text = "Atualizar Tabuleiro";
            this.btnSomenteAtualizarTabuleiro.UseVisualStyleBackColor = false;
            this.btnSomenteAtualizarTabuleiro.Click += new System.EventHandler(this.btnSomenteAtualizarTabuleiro_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.numericUpDown1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.numericUpDown1.Location = new System.Drawing.Point(150, 222);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(36, 22);
            this.numericUpDown1.TabIndex = 54;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // btnEntrarPartidaEmergencia
            // 
            this.btnEntrarPartidaEmergencia.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnEntrarPartidaEmergencia.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnEntrarPartidaEmergencia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEntrarPartidaEmergencia.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEntrarPartidaEmergencia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnEntrarPartidaEmergencia.Location = new System.Drawing.Point(225, 200);
            this.btnEntrarPartidaEmergencia.Name = "btnEntrarPartidaEmergencia";
            this.btnEntrarPartidaEmergencia.Size = new System.Drawing.Size(128, 41);
            this.btnEntrarPartidaEmergencia.TabIndex = 53;
            this.btnEntrarPartidaEmergencia.Text = "Entrar Partida em Jogo";
            this.btnEntrarPartidaEmergencia.UseVisualStyleBackColor = false;
            this.btnEntrarPartidaEmergencia.Click += new System.EventHandler(this.btnEntrarPartidaEmergencia_Click);
            // 
            // txtSenhaPartidaEmergencia
            // 
            this.txtSenhaPartidaEmergencia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.txtSenhaPartidaEmergencia.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtSenhaPartidaEmergencia.Location = new System.Drawing.Point(225, 173);
            this.txtSenhaPartidaEmergencia.Name = "txtSenhaPartidaEmergencia";
            this.txtSenhaPartidaEmergencia.Size = new System.Drawing.Size(130, 22);
            this.txtSenhaPartidaEmergencia.TabIndex = 52;
            // 
            // txtIdPartidaEmergencia
            // 
            this.txtIdPartidaEmergencia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.txtIdPartidaEmergencia.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtIdPartidaEmergencia.Location = new System.Drawing.Point(225, 128);
            this.txtIdPartidaEmergencia.Name = "txtIdPartidaEmergencia";
            this.txtIdPartidaEmergencia.Size = new System.Drawing.Size(130, 22);
            this.txtIdPartidaEmergencia.TabIndex = 51;
            // 
            // lblSenhaPartidaEmergencia
            // 
            this.lblSenhaPartidaEmergencia.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSenhaPartidaEmergencia.AutoSize = true;
            this.lblSenhaPartidaEmergencia.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSenhaPartidaEmergencia.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblSenhaPartidaEmergencia.Location = new System.Drawing.Point(222, 153);
            this.lblSenhaPartidaEmergencia.Name = "lblSenhaPartidaEmergencia";
            this.lblSenhaPartidaEmergencia.Size = new System.Drawing.Size(113, 17);
            this.lblSenhaPartidaEmergencia.TabIndex = 18;
            this.lblSenhaPartidaEmergencia.Text = "Senha da Partida:";
            // 
            // lblIdPartidaEmergencia
            // 
            this.lblIdPartidaEmergencia.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblIdPartidaEmergencia.AutoSize = true;
            this.lblIdPartidaEmergencia.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdPartidaEmergencia.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblIdPartidaEmergencia.Location = new System.Drawing.Point(222, 108);
            this.lblIdPartidaEmergencia.Name = "lblIdPartidaEmergencia";
            this.lblIdPartidaEmergencia.Size = new System.Drawing.Size(88, 17);
            this.lblIdPartidaEmergencia.TabIndex = 18;
            this.lblIdPartidaEmergencia.Text = "ID da Partida:";
            // 
            // lblSenhaJogadorEmergencia
            // 
            this.lblSenhaJogadorEmergencia.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSenhaJogadorEmergencia.AutoSize = true;
            this.lblSenhaJogadorEmergencia.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSenhaJogadorEmergencia.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblSenhaJogadorEmergencia.Location = new System.Drawing.Point(222, 63);
            this.lblSenhaJogadorEmergencia.Name = "lblSenhaJogadorEmergencia";
            this.lblSenhaJogadorEmergencia.Size = new System.Drawing.Size(120, 17);
            this.lblSenhaJogadorEmergencia.TabIndex = 18;
            this.lblSenhaJogadorEmergencia.Text = "Senha do Jogador:";
            // 
            // lblTempoSicronizacao
            // 
            this.lblTempoSicronizacao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTempoSicronizacao.AutoSize = true;
            this.lblTempoSicronizacao.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempoSicronizacao.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblTempoSicronizacao.Location = new System.Drawing.Point(6, 224);
            this.lblTempoSicronizacao.Name = "lblTempoSicronizacao";
            this.lblTempoSicronizacao.Size = new System.Drawing.Size(138, 17);
            this.lblTempoSicronizacao.TabIndex = 18;
            this.lblTempoSicronizacao.Text = "Tempo Sincronização:";
            // 
            // lblIdJogadorEmergencia
            // 
            this.lblIdJogadorEmergencia.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblIdJogadorEmergencia.AutoSize = true;
            this.lblIdJogadorEmergencia.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdJogadorEmergencia.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblIdJogadorEmergencia.Location = new System.Drawing.Point(222, 18);
            this.lblIdJogadorEmergencia.Name = "lblIdJogadorEmergencia";
            this.lblIdJogadorEmergencia.Size = new System.Drawing.Size(95, 17);
            this.lblIdJogadorEmergencia.TabIndex = 18;
            this.lblIdJogadorEmergencia.Text = "ID do Jogador:";
            // 
            // txtSenhaJogadorEmergencia
            // 
            this.txtSenhaJogadorEmergencia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.txtSenhaJogadorEmergencia.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtSenhaJogadorEmergencia.Location = new System.Drawing.Point(225, 83);
            this.txtSenhaJogadorEmergencia.Name = "txtSenhaJogadorEmergencia";
            this.txtSenhaJogadorEmergencia.Size = new System.Drawing.Size(130, 22);
            this.txtSenhaJogadorEmergencia.TabIndex = 50;
            // 
            // txtIdJogadorEmergencia
            // 
            this.txtIdJogadorEmergencia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.txtIdJogadorEmergencia.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtIdJogadorEmergencia.Location = new System.Drawing.Point(225, 38);
            this.txtIdJogadorEmergencia.Name = "txtIdJogadorEmergencia";
            this.txtIdJogadorEmergencia.Size = new System.Drawing.Size(130, 22);
            this.txtIdJogadorEmergencia.TabIndex = 49;
            // 
            // btnHabilitarDebug
            // 
            this.btnHabilitarDebug.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnHabilitarDebug.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnHabilitarDebug.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHabilitarDebug.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHabilitarDebug.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnHabilitarDebug.Location = new System.Drawing.Point(8, 176);
            this.btnHabilitarDebug.Name = "btnHabilitarDebug";
            this.btnHabilitarDebug.Size = new System.Drawing.Size(99, 40);
            this.btnHabilitarDebug.TabIndex = 48;
            this.btnHabilitarDebug.Text = "Habilitar Debug File";
            this.btnHabilitarDebug.UseVisualStyleBackColor = false;
            this.btnHabilitarDebug.Click += new System.EventHandler(this.btnHabilitarDebug_Click);
            // 
            // btnAlg13
            // 
            this.btnAlg13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAlg13.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAlg13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlg13.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlg13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnAlg13.Location = new System.Drawing.Point(160, 82);
            this.btnAlg13.Name = "btnAlg13";
            this.btnAlg13.Size = new System.Drawing.Size(36, 23);
            this.btnAlg13.TabIndex = 47;
            this.btnAlg13.Text = "a13";
            this.btnAlg13.UseVisualStyleBackColor = false;
            this.btnAlg13.Click += new System.EventHandler(this.btnAlg13_Click);
            // 
            // btnAlg10
            // 
            this.btnAlg10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAlg10.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAlg10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlg10.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlg10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnAlg10.Location = new System.Drawing.Point(116, 82);
            this.btnAlg10.Name = "btnAlg10";
            this.btnAlg10.Size = new System.Drawing.Size(38, 23);
            this.btnAlg10.TabIndex = 46;
            this.btnAlg10.Text = "a10";
            this.btnAlg10.UseVisualStyleBackColor = false;
            this.btnAlg10.Click += new System.EventHandler(this.btnAlg10_Click);
            // 
            // btnTimer
            // 
            this.btnTimer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnTimer.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnTimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimer.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnTimer.Location = new System.Drawing.Point(113, 147);
            this.btnTimer.Name = "btnTimer";
            this.btnTimer.Size = new System.Drawing.Size(83, 23);
            this.btnTimer.TabIndex = 20;
            this.btnTimer.Text = "Timer Tick";
            this.btnTimer.UseVisualStyleBackColor = false;
            this.btnTimer.Click += new System.EventHandler(this.btnTimer_Click);
            // 
            // btnHabilitarTimer
            // 
            this.btnHabilitarTimer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnHabilitarTimer.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnHabilitarTimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHabilitarTimer.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHabilitarTimer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnHabilitarTimer.Location = new System.Drawing.Point(8, 147);
            this.btnHabilitarTimer.Name = "btnHabilitarTimer";
            this.btnHabilitarTimer.Size = new System.Drawing.Size(99, 23);
            this.btnHabilitarTimer.TabIndex = 20;
            this.btnHabilitarTimer.Text = "Habilitar Timer";
            this.btnHabilitarTimer.UseVisualStyleBackColor = false;
            this.btnHabilitarTimer.Click += new System.EventHandler(this.btnHabilitarTimer_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtdebug);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox2.Location = new System.Drawing.Point(507, 361);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(361, 297);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Debug";
            // 
            // txtdebug
            // 
            this.txtdebug.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtdebug.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.txtdebug.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtdebug.Location = new System.Drawing.Point(6, 31);
            this.txtdebug.MaxLength = 10;
            this.txtdebug.Multiline = true;
            this.txtdebug.Name = "txtdebug";
            this.txtdebug.Size = new System.Drawing.Size(349, 260);
            this.txtdebug.TabIndex = 4;
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.btnMinimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimizar.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinimizar.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.btnMinimizar.Location = new System.Drawing.Point(398, 12);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(32, 32);
            this.btnMinimizar.TabIndex = 43;
            this.btnMinimizar.Text = "_";
            this.btnMinimizar.UseVisualStyleBackColor = false;
            this.btnMinimizar.Click += new System.EventHandler(this.btnMinimizar_Click);
            this.btnMinimizar.MouseLeave += new System.EventHandler(this.btnMinimizar_MouseLeave);
            this.btnMinimizar.MouseHover += new System.EventHandler(this.btnMinimizar_MouseHover);
            // 
            // labelIndicadordeErro
            // 
            this.labelIndicadordeErro.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelIndicadordeErro.AutoSize = true;
            this.labelIndicadordeErro.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIndicadordeErro.ForeColor = System.Drawing.Color.Red;
            this.labelIndicadordeErro.Location = new System.Drawing.Point(-11, 681);
            this.labelIndicadordeErro.Name = "labelIndicadordeErro";
            this.labelIndicadordeErro.Size = new System.Drawing.Size(11, 16);
            this.labelIndicadordeErro.TabIndex = 45;
            this.labelIndicadordeErro.Text = "!";
            this.labelIndicadordeErro.Visible = false;
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(18)))), ((int)(((byte)(23)))));
            this.ClientSize = new System.Drawing.Size(480, 700);
            this.Controls.Add(this.labelIndicadordeErro);
            this.Controls.Add(this.btnMinimizar);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gbConfiguracoes);
            this.Controls.Add(this.lblErro);
            this.Controls.Add(this.lblArquivoDebug);
            this.Controls.Add(this.lblVersao);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbLogo);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.painelTabuleiro);
            this.Controls.Add(this.painelLobby);
            this.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MePresidenta";
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).EndInit();
            this.painelLobby.ResumeLayout(false);
            this.painelLobby.PerformLayout();
            this.gbEntrarPartida.ResumeLayout(false);
            this.gbEntrarPartida.PerformLayout();
            this.gbCriarPartida.ResumeLayout(false);
            this.gbCriarPartida.PerformLayout();
            this.painelTabuleiro.ResumeLayout(false);
            this.painelTabuleiro.PerformLayout();
            this.gbDesempregados.ResumeLayout(false);
            this.gbVotacao.ResumeLayout(false);
            this.gbPosicionamento.ResumeLayout(false);
            this.gbPosicionamento.PerformLayout();
            this.gbJogadores.ResumeLayout(false);
            this.gbJogadores.PerformLayout();
            this.gbConfiguracoes.ResumeLayout(false);
            this.gbConfiguracoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbLogo;
        private System.Windows.Forms.Panel painelLobby;
        private System.Windows.Forms.ListView lstPartidas;
        private System.Windows.Forms.ColumnHeader chCodigo;
        private System.Windows.Forms.ColumnHeader chNomePartida;
        private System.Windows.Forms.ColumnHeader chStatusPartida;
        private System.Windows.Forms.Label lblVersao;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox gbEntrarPartida;
        private System.Windows.Forms.Label lblEntrarPartida;
        private System.Windows.Forms.TextBox txtSenhadaPartidaEntrar;
        private System.Windows.Forms.Label lblNomeJogador;
        private System.Windows.Forms.Label lblSenhaPartida_Entrar;
        private System.Windows.Forms.TextBox txtNomedoJogador;
        private System.Windows.Forms.Button btnEntrarPartida;
        private System.Windows.Forms.Label lblInformacaoDesenvolvido;
        private System.Windows.Forms.GroupBox gbCriarPartida;
        private System.Windows.Forms.Label lblCriarPartida;
        private System.Windows.Forms.TextBox txtSenhaPartida;
        private System.Windows.Forms.Label lblSenhaPartida_Criar;
        private System.Windows.Forms.Button btnCriarPartida;
        private System.Windows.Forms.TextBox txtNomedaPartida;
        private System.Windows.Forms.Label lblNomePartida;
        private System.Windows.Forms.Label lblIdPartida;
        private System.Windows.Forms.Button btnAtualizar;
        private System.Windows.Forms.Label lblDebugFileName;
        private System.Windows.Forms.Panel painelTabuleiro;
        private System.Windows.Forms.Button btnIniciarPartida;
        private System.Windows.Forms.GroupBox gbVotacao;
        private System.Windows.Forms.Button btnNao;
        private System.Windows.Forms.Label labelPerguntaVotacao;
        private System.Windows.Forms.Button btnSim;
        private System.Windows.Forms.GroupBox gbPosicionamento;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnPosicionar;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox gbJogadores;
        private System.Windows.Forms.Label lblNumRodada;
        private System.Windows.Forms.Label lblPontuacaoAtual;
        private System.Windows.Forms.Label lblRodada;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button n04;
        private System.Windows.Forms.Button n14;
        private System.Windows.Forms.Button n03;
        private System.Windows.Forms.Button n13;
        private System.Windows.Forms.Button n02;
        private System.Windows.Forms.Button n12;
        private System.Windows.Forms.Button n01;
        private System.Windows.Forms.Button n11;
        private System.Windows.Forms.Button n24;
        private System.Windows.Forms.Button n34;
        private System.Windows.Forms.Button n23;
        private System.Windows.Forms.Button n33;
        private System.Windows.Forms.Button n44;
        private System.Windows.Forms.Button n22;
        private System.Windows.Forms.Button n43;
        private System.Windows.Forms.Button n32;
        private System.Windows.Forms.Button n54;
        private System.Windows.Forms.Button n21;
        private System.Windows.Forms.Button n42;
        private System.Windows.Forms.Button n31;
        private System.Windows.Forms.Button n53;
        private System.Windows.Forms.Button n41;
        private System.Windows.Forms.Button n52;
        private System.Windows.Forms.Button n51;
        private System.Windows.Forms.Button n10;
        private System.Windows.Forms.Label lblArquivoDebug;
        private System.Windows.Forms.Label lblErro;
        private System.Windows.Forms.Button btnPromover;
        private System.Windows.Forms.Button btnAlg0;
        private System.Windows.Forms.Button btnAlg5;
        private System.Windows.Forms.Button btnAlg7;
        private System.Windows.Forms.Button btnAlg4;
        private System.Windows.Forms.Button btnAlg3;
        private System.Windows.Forms.Button btnAlg2;
        private System.Windows.Forms.Button btnAlg1;
        private System.Windows.Forms.Button btnAutoJogo;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.GroupBox gbConfiguracoes;
        private System.Windows.Forms.Button btnTimer;
        private System.Windows.Forms.Button btnHabilitarTimer;
        private System.Windows.Forms.GroupBox gbDesempregados;
        private System.Windows.Forms.Button btnd11;
        private System.Windows.Forms.Button btnd10;
        private System.Windows.Forms.Button btnd9;
        private System.Windows.Forms.Button btnd8;
        private System.Windows.Forms.Button btnd7;
        private System.Windows.Forms.Button btnd6;
        private System.Windows.Forms.Button btnd5;
        private System.Windows.Forms.Button btnd4;
        private System.Windows.Forms.Button btnd3;
        private System.Windows.Forms.Button btnd2;
        private System.Windows.Forms.Button btnd1;
        private System.Windows.Forms.Button btnd0;
        private System.Windows.Forms.Label lblPontuacaoTotal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnd12;
        private System.Windows.Forms.Button j1;
        private System.Windows.Forms.Button j5;
        private System.Windows.Forms.Button j4;
        private System.Windows.Forms.Button j3;
        private System.Windows.Forms.Label lblPontos5;
        private System.Windows.Forms.Label lblPontos4;
        private System.Windows.Forms.Label lblPontos3;
        private System.Windows.Forms.Label lblPontos2;
        private System.Windows.Forms.Label lblPontos1;
        private System.Windows.Forms.Label lblJogadas5;
        private System.Windows.Forms.Label lblJogadas4;
        private System.Windows.Forms.Label lblJogadas3;
        private System.Windows.Forms.Label lblJogadas2;
        private System.Windows.Forms.Label lblJogadas1;
        private System.Windows.Forms.Label lblJogadas0;
        private System.Windows.Forms.Label lblPontos0;
        private System.Windows.Forms.Button j2;
        private System.Windows.Forms.Button nao53;
        private System.Windows.Forms.Button nao52;
        private System.Windows.Forms.Button nao51;
        private System.Windows.Forms.Button nao50;
        private System.Windows.Forms.Button nao43;
        private System.Windows.Forms.Button nao42;
        private System.Windows.Forms.Button nao41;
        private System.Windows.Forms.Button nao40;
        private System.Windows.Forms.Button nao33;
        private System.Windows.Forms.Button nao32;
        private System.Windows.Forms.Button nao31;
        private System.Windows.Forms.Button nao30;
        private System.Windows.Forms.Button nao23;
        private System.Windows.Forms.Button nao22;
        private System.Windows.Forms.Button nao21;
        private System.Windows.Forms.Button nao20;
        private System.Windows.Forms.Button nao13;
        private System.Windows.Forms.Button nao12;
        private System.Windows.Forms.Button nao11;
        private System.Windows.Forms.Button nao10;
        private System.Windows.Forms.Button nao03;
        private System.Windows.Forms.Button nao02;
        private System.Windows.Forms.Button nao01;
        private System.Windows.Forms.Button nao00;
        private System.Windows.Forms.Button j0;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtdebug;
        private System.Windows.Forms.TextBox txtSetor;
        private System.Windows.Forms.TextBox txtPersonagem;
        private System.Windows.Forms.Button btnConfiguracoes;
        private System.Windows.Forms.Button btnSairPartida;
        private System.Windows.Forms.Button btnAlg10;
        private System.Windows.Forms.Button btnAlg13;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelNomePartidaSelecionada;
        private System.Windows.Forms.Button btninfo;
        private System.Windows.Forms.Button btnHabilitarDebug;
        private System.Windows.Forms.Button btnEntrarPartidaEmergencia;
        private System.Windows.Forms.TextBox txtSenhaPartidaEmergencia;
        private System.Windows.Forms.TextBox txtIdPartidaEmergencia;
        private System.Windows.Forms.TextBox txtSenhaJogadorEmergencia;
        private System.Windows.Forms.TextBox txtIdJogadorEmergencia;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button btnSomenteAtualizarTabuleiro;
        private System.Windows.Forms.Label lblSenhaPartidaEmergencia;
        private System.Windows.Forms.Label lblIdPartidaEmergencia;
        private System.Windows.Forms.Label lblSenhaJogadorEmergencia;
        private System.Windows.Forms.Label lblIdJogadorEmergencia;
        private System.Windows.Forms.Button btnMinimizar;
        private System.Windows.Forms.Label lblTempoSicronizacao;
        private System.Windows.Forms.Label labelVotacao5;
        private System.Windows.Forms.Label labelVotacao4;
        private System.Windows.Forms.Label labelVotacao3;
        private System.Windows.Forms.Label labelVotacao2;
        private System.Windows.Forms.Label labelVotacao1;
        private System.Windows.Forms.Label labelVotacao0;
        private System.Windows.Forms.Label labelIndicadordeErro;
    }
}

